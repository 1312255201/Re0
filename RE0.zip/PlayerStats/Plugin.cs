using Exiled.API.Enums;
using Exiled.API.Features;
using Exiled.Events.Handlers;
using HarmonyLib;
using System.Threading;
using System.Threading.Tasks;

namespace RE0
{
	public class Plugin : Plugin<YYYlikeconfig>
	{
		private EventHandlers server;

		public override void OnEnabled()
		{
			base.OnEnabled();
			RegisterEvents();
			Log.Info("Exiled2.0插件读取完毕");
		}

		private void RegisterEvents()
		{
			server = new EventHandlers();
			Exiled.Events.Handlers.Player.Died += server.OnPlayerDeath;
			Exiled.Events.Handlers.Server.RoundEnded += server.OnRoundEnd;
			Exiled.Events.Handlers.Player.Died += server.OnPlayerDeath;
			Exiled.Events.Handlers.Player.DroppingItem += server.OnDropItem;
			Exiled.Events.Handlers.Player.Hurting += server.OnPlayerHurt;
			Exiled.Events.Handlers.Server.RoundStarted += server.OnRoundStart;
			Exiled.Events.Handlers.Player.Joined += server.OnPlayerJoin;
			Exiled.Events.Handlers.Server.RespawningTeam += server.OnTeamRespawn;
			Exiled.Events.Handlers.Server.SendingRemoteAdminCommand += server.OnSendingRemoteAdminCommand;
			Exiled.Events.Handlers.Player.PickingUpItem += server.OnPickUpItem;
			Exiled.Events.Handlers.Player.InteractingDoor += server.OnInteractingDoor;
			Exiled.Events.Handlers.Warhead.Stopping += server.ONWarheadCancelled;
			Exiled.Events.Handlers.Server.SendingConsoleCommand+= server.OnSendingConsoleCommand;
			Exiled.Events.Handlers.Player.TriggeringTesla+= server.OnTriggeringTesla;
			Exiled.Events.Handlers.Player.EnteringPocketDimension += server.OnEnteringPocketDimension;
			Exiled.Events.Handlers.Server.EndingRound += server.OnEndingRound;
			Exiled.Events.Handlers.Player.UsingMedicalItem += server.Onmeddikusing;
			Exiled.Events.Handlers.Player.Spawning += server.OnPlayerSpawn;
			Exiled.Events.Handlers.Player.Shooting += server.Shot;
			Exiled.Events.Handlers.Player.Verified += server.OnVerified;
		}
		


		public override void OnDisabled()
		{
			base.OnDisabled();
			UnregisterEvents();
		}

		private void UnregisterEvents()
		{
			Exiled.Events.Handlers.Server.RoundStarted -= server.OnRoundStart;
			Exiled.Events.Handlers.Server.RoundEnded -= server.OnRoundEnd;
			Exiled.Events.Handlers.Player.Died -= server.OnPlayerDeath;
			Exiled.Events.Handlers.Player.DroppingItem -= server.OnDropItem;
			Exiled.Events.Handlers.Player.Hurting -= server.OnPlayerHurt;
			Exiled.Events.Handlers.Player.Joined -= server.OnPlayerJoin;
			Exiled.Events.Handlers.Server.RespawningTeam -= server.OnTeamRespawn;
			Exiled.Events.Handlers.Server.SendingRemoteAdminCommand -= server.OnSendingRemoteAdminCommand;
			Exiled.Events.Handlers.Player.PickingUpItem -= server.OnPickUpItem;
			Exiled.Events.Handlers.Player.InteractingDoor -= server.OnInteractingDoor;
			Exiled.Events.Handlers.Warhead.Stopping -= server.ONWarheadCancelled;
			Exiled.Events.Handlers.Server.SendingConsoleCommand -= server.OnSendingConsoleCommand;
			Exiled.Events.Handlers.Player.EnteringPocketDimension -= server.OnEnteringPocketDimension;
			Exiled.Events.Handlers.Player.TriggeringTesla -= server.OnTriggeringTesla;

			Exiled.Events.Handlers.Server.EndingRound -= server.OnEndingRound;
			Exiled.Events.Handlers.Player.UsingMedicalItem -= server.Onmeddikusing;
			Exiled.Events.Handlers.Player.Spawning -= server.OnPlayerSpawn;
			Exiled.Events.Handlers.Player.Shooting -= server.Shot;
			Exiled.Events.Handlers.Player.Verified -= server.OnVerified;

			server = null;
		}
	}
}
